update abbendis set account_id=id where numCollected=0 and pet_crc32<>0 and account_id<>id
select *,count(id) as count from abbendis where numCollected=0 and pet_crc32<>0 and account_id<>id group by account_id limit 20

update arthas set account_id=id where numCollected=0 and pet_crc32<>0 and account_id<>id

select *,count(id) as count from arthas where numCollected=0 and pet_crc32<>0 and account_id<>id group by account_id limit 20

update aggramar set account_id=id where numCollected=0 and pet_crc32<>0 and account_id<>id
select *,count(id) as count from aggramar where numCollected=0 and pet_crc32<>0 and account_id<>id group by account_id limit 20

update argus set account_id=id where numCollected=0 and pet_crc32<>0 and account_id<>id
select *,count(id) as count from argus where numCollected=0 and pet_crc32<>0 and account_id<>id group by account_id limit 20


-802316575


update shadow_council set account_id=id where numCollected=0 and pet_crc32<>0 and account_id<>id
select *,count(id) as count from shadow_council where numCollected=0 and pet_crc32<>0 and account_id<>id group by account_id limit 20



select id,name,achievementPoints,count(id) as count from abbendis where pet_crc32>0 group by pet_crc32 having count>1 order by count desc limit 20


select a.id, a.name, a.class, a.race, a.gender, a.level, a.rank, a.guild_id, a.achievementPoints, a.pet_crc32, a.numCollected, a.lastModified, a.account_id, count(a.id) as count from wow_item_db.abbendis as a WHERE a.account_id=552  ORDER BY a.name asc LIMIT 40 OFFSET 0


select id,name,achievementPoints,guild_id,numCollected,lastModified,account_id from abbendis where account_id=552



select count(*) as count from abbendis where id in (selelct max(rowid) from abbendis group by id,a)


select count(id) from xxx where id in (select max(id) from xxx group by account_id)


