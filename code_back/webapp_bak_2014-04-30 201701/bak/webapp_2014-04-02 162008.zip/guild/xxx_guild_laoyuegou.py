#!/usr/bin/python
# -*- coding: utf-8 -*-

# -------------------------------------------------------------------------------
# Name:       down_guild_laoyuegou_str
# Purpose:
#
# Author:      Administrator
#
# Created:     20/03/2014
# Copyright:   (c) Administrator 2014
# Licence:     <your licence>
# -------------------------------------------------------------------------------

import sys
import MySQLdb
import json
import os
import datetime
import urllib2
import time
import random
# BeautifulSoup for HTML
from BeautifulSoup import BeautifulSoup
import re

# my download http
import inc_download


def down_guild_laoyuegou_str():

    inc_download.log_with_time('SET Read ing... ')
    # print base_cfg
    bfj = json.loads(inc_download.base_cfg)
    si = bfj['MySQL_set']

    inc_download.log_with_time('DB Link ing... ')
    conn = MySQLdb.connect(host=si['host'], user=si['user'],
                           passwd=si['passwd'], db=si['item_db'],
                           charset=si['charset'])
    cursor_fwq = conn.cursor()
    cursor_guild = conn.cursor()
    cursor_info = conn.cursor()
    cursor_info.execute('set names "utf8"')
    cursor_info.execute('SET GLOBAL innodb_flush_log_at_trx_commit = 0')
    cursor_info.execute('SET UNIQUE_CHECKS = 0')
    conn.commit()

    laoyuegou_url = r'http://www.laoyuegou.com/game/wow/ladder/ladderTwentyDetail/worldRealm/1/realm/%s/page/1.html'
    laoyuegou_www = r'http://www.laoyuegou.com'

    inc_download.log_with_time('DATE download ing... ')
    hp = inc_download.HttpPool(40, 20, inc_download.base_fail_op, inc_download.base_log)

    sql_info = 'replace into ' + si['wow_guild_list'] + " (name,total,area,group_str,realm,faction) values ('%s','%s','%s','%s','%s','%s')"
    sql_select = 'select id from ' + si['wow_guild_list']  + ' where name = "%s" and realm = "%s" limit 1'

    sql_fwq = 'select slug,zname,fwqID from ' + si['db'] + '.' + si['fwq_all_info'] + ' where fwqID>=252 and fwqID<=991 order by fwqID'
    cursor_fwq.execute(sql_fwq)
    count_download = 0L

    while True:
        row_fwq = cursor_fwq.fetchone()
        if row_fwq == None:
            break

        inc_download.log_with_time(row_fwq[1] + '(fwqID:' + str(row_fwq[2]) + ') ->  download ing... ', new_line = True)

        count_download = count_download + 1

        url = laoyuegou_url % ( row_fwq[1].encode('utf-8') )
        task_id = row_fwq[2] * 100 + 1

        #print task_id,url.decode('utf-8').encode('gbk')
        while True:
            if hp.get_doing_count_now() < hp.get_doing_count_max():
                if hp.add_task(task_id, url):
                    inc_download.log_with_info(str(task_id)+'(add)')
                    break;
            results = hp.get_results()
            if not results:
                time.sleep(1.0 * random.random())
            else:
                for i in results:
                    if laoyuegou_json_file(i, laoyuegou_www, sql_info, sql_select, cursor_info, conn, hp):
                        inc_download.log_with_info(str(i[0])+'(get)')
                    else:
                        inc_download.log_with_info(str(i[0])+'(error)')

    inc_download.log_with_info('waite to end-> ', new_line = True)
    count_waite = 0L
    while hp.get_doing_count_now() > 0:
        results = hp.get_results()
        if not results:
            if count_waite > 100 or count_waite > hp.get_doing_count_now()*30:
                hp.set_doing_count_now(0)
                break;
            time.sleep(1.0 * random.random())
            count_waite = count_waite + 1
            inc_download.log_with_info('.')
        else:
            count_waite = 0L
            for i in results:
                if laoyuegou_json_file(i, laoyuegou_www, sql_info, sql_select, cursor_info, conn, hp):
                    inc_download.log_with_info(str(i[0])+'(get)')
                else:
                    inc_download.log_with_info(str(i[0])+'(error)')

    cursor_info.execute('SET GLOBAL innodb_flush_log_at_trx_commit = 1')
    cursor_info.execute('SET UNIQUE_CHECKS = 1')
    conn.commit()
    cursor_fwq.close()
    cursor_guild.close()
    cursor_info.close()
    conn.close()
    return count_download


def laoyuegou_json_file(task_info, base_www, sql_in, sql_select, cursor_in, conn_in, hp):

    task_id = task_info[0]
    rs = task_info[1]
    url = task_info[2]

    if len(rs) < 40:
        if rs == str(inc_download.HTTP_ERROR_PAGE_NOT_FOUND)  or rs == str(inc_download.HTTP_ERROR_REQUEST_TIME_OUT) or rs == str(inc_download.HTTP_ERROR_SERVER_ERROR):
            pass;
        return False

    rs_next_li = BeautifulSoup(rs).find(attrs={'class':re.compile("next$")})
    if rs_next_li:
        rs_next_a = BeautifulSoup(str(rs_next_li)).find('a')
        rs_next_url = base_www + rs_next_a['href']
        if hp.add_task(task_id + 1, rs_next_url):
            print str(task_id + 1),'(+add)',


    rs_tbody = BeautifulSoup(rs).find('tbody')
    if rs_tbody:
        rs_tr = BeautifulSoup(str(rs_tbody)).findAll('tr')
        for tr in rs_tr:
            tr_temp = str(tr)

            num_temp1 = tr_temp.find('.html">',150) + 7
            num_temp2 = tr_temp.find('</a>',num_temp1)
            tr_name = tr_temp[ num_temp1:num_temp2 ]
            num_temp1 = tr_temp.find('国服 - ',num_temp2 + 10)
            num_temp2 = tr_temp.find('</a>',num_temp1 + 1,num_temp1 + 50)
            tr_realm = tr_temp[ num_temp1:num_temp2 ].replace('国服 - ', '')
            tr_name = tr_name.replace('\t', '')
            tr_name = tr_name.decode('utf-8')
            tr_realm = tr_realm.decode('utf-8')
            if tr_name.find('/') >= 0 or tr_name.find('/') >= 0:
                print tr_name,'--',tr_realm,'(str select error) '
            try:
                if cursor_in.execute( sql_select % (tr_name, tr_realm) ) == 0:
                    cursor_in.execute( sql_in % (tr_name,0,'CN','laoyuegou',tr_realm,3) )
                    #print tr_name,'--',tr_realm,'(new) ',
                else:
                    #print tr_name,'--',tr_realm,'(new) ',
                    pass;
            except Exception,ex:
                print '\n' + str(task_id) + ' ERROR SQL -> ',
                print Exception,':',ex

        conn_in.commit()
        return True;
    else:
        return False;


def main():
    main_start = datetime.datetime.now()

    main_count = down_guild_laoyuegou_str()

    print '\n', datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S  '), str(main_count), ' items OVER!'
    main_end = datetime.datetime.now()
    print '\nUSE Time : ', str(main_end - main_start)


if __name__ == '__main__':
    main()


