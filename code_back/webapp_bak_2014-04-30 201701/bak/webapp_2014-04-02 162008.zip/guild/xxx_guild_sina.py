#!/usr/bin/python
# -*- coding: utf-8 -*-

# -------------------------------------------------------------------------------
# Name:        down_guild_sina_str
# Purpose:
#
# Author:      Administrator
#
# Created:     20/03/2014
# Copyright:   (c) Administrator 2014
# Licence:     <your licence>
# -------------------------------------------------------------------------------

import sys
import MySQLdb
import json
import os
import datetime
import urllib2
import time
import random
# BeautifulSoup for HTML
from BeautifulSoup import BeautifulSoup
import re

# my download http
import inc_download


def down_guild_sina_str():

    inc_download.log_with_time('SET Read ing... ')
    # print base_cfg
    bfj = json.loads(inc_download.base_cfg)
    si = bfj['MySQL_set']

    inc_download.log_with_time('DB Link ing... ')
    conn = MySQLdb.connect(host=si['host'], user=si['user'],
                           passwd=si['passwd'], db=si['item_db'],
                           charset=si['charset'])
    cursor_fwq = conn.cursor()
    cursor_guild = conn.cursor()
    cursor_info = conn.cursor()
    cursor_info.execute('set names "utf8"')
    cursor_info.execute('SET GLOBAL innodb_flush_log_at_trx_commit = 0')
    cursor_info.execute('SET UNIQUE_CHECKS = 0')
    conn.commit()

    sina_url = r'http://armory.games.sina.com.cn/GuildList.aspx?action=ajaxload&area=CN&realm=%s&faction=%s&playersmin=%s&playersmax=%s'

    inc_download.log_with_time('DATE download ing... ')
    hp = inc_download.HttpPool(40, 20, inc_download.base_fail_op, inc_download.base_log)

    sql_info = 'replace into ' + si['wow_guild_list'] + " (name,total,area,group_str,realm,faction) values ('%s','%s','%s','%s','%s','%s')"
    sql_select = 'select id from ' + si['wow_guild_list']  + ' where name = "%s" and realm = "%s" limit 1'

    sql_fwq = 'select slug,zname,fwqID from ' + si['db'] + '.' + si['fwq_all_info'] + ' where fwqID>=42 and fwqID<=822 order by fwqID'
    cursor_fwq.execute(sql_fwq)
    count_download = 0L

    while True:
        row_fwq = cursor_fwq.fetchone()
        if row_fwq == None:
            break

        inc_download.log_with_time(row_fwq[1] + '(fwqID:' + str(row_fwq[2]) + ') ->  download ing... ', new_line = True)

        count_download = count_download + 1
        for faction in ['a','h']:
            for playersmin in range(0,13):
                if playersmin <= 4:     # 0-4  5  0-8:2 to 1-9:2  1
                    playersmin_str = str(playersmin*2)
                    playersmax_str = str(playersmin*2 + 1)
                elif playersmin <= 7:   # 5-7  3  10-70:30 to 39-99:30  29
                    playersmin_str = str( (playersmin - 5)*30 + 10)
                    playersmax_str = str( (playersmin - 5)*30 + 39)
                elif playersmin <= 11:  # 8-11  4  100-400:100 to 199-499:100  99
                    playersmin_str = str( (playersmin - 8)*100 + 100)
                    playersmax_str = str( (playersmin - 8)*100 + 199)
                elif playersmin == 12:  # 12  500 to NaN
                    playersmin_str = '500'
                    playersmax_str = ''

                url = sina_url % (row_fwq[1].encode('utf-8'), faction, playersmin_str, playersmax_str )
                task_id = (100 + playersmin) if (faction == 'a') else (200 + playersmin)

                #print task_id,url.decode('utf-8').encode('gbk')
                while True:
                    if hp.get_doing_count_now() < hp.get_doing_count_max():
                        if hp.add_task(task_id, url):
                            inc_download.log_with_info(str(task_id)+'(add)')
                            break;
                    results = hp.get_results()
                    if not results:
                        time.sleep(1.0 * random.random())
                    else:
                        for i in results:
                            if sina_json_file(i, sql_info, sql_select, cursor_info, conn, hp):
                                inc_download.log_with_info(str(i[0])+'(get)')
                            else:
                                inc_download.log_with_info(str(i[0])+'(error)')

    inc_download.log_with_info('waite to end-> ', new_line = True)
    count_waite = 0L
    while hp.get_doing_count_now() > 0:
        results = hp.get_results()
        if not results:
            if count_waite > 100 or count_waite > hp.get_doing_count_now()*30:
                hp.set_doing_count_now(0)
                break;
            time.sleep(1.0 * random.random())
            count_waite = count_waite + 1
            inc_download.log_with_info('.')
        else:
            count_waite = 0L
            for i in results:
                if sina_json_file(i, sql_info, sql_select, cursor_info, conn, hp):
                    inc_download.log_with_info(str(i[0])+'(get)')
                else:
                    inc_download.log_with_info(str(i[0])+'(error)')

    cursor_info.execute('SET GLOBAL innodb_flush_log_at_trx_commit = 1')
    cursor_info.execute('SET UNIQUE_CHECKS = 1')
    conn.commit()
    cursor_fwq.close()
    cursor_guild.close()
    cursor_info.close()
    conn.close()
    return count_download


def sina_json_file(task_info, sql_in, sql_select, cursor_in, conn_in, hp):

    task_id = task_info[0]
    rs = task_info[1]
    url = task_info[2]

    if len(rs) < 40:
        if rs == str(inc_download.HTTP_ERROR_PAGE_NOT_FOUND)  or rs == str(inc_download.HTTP_ERROR_REQUEST_TIME_OUT) or rs == str(inc_download.HTTP_ERROR_SERVER_ERROR):
            if task_id < 8000:
                hp.add_task(task_id + 1000, url)
                print '\n',str(task_id),' re add -> '
        return False

    try:
        rs = rs.replace('var guildsdata = ','')
        rs = rs.replace('{count:','{"count":')
        rs = rs.replace(',guilds:',',"guilds":')
        rs = rs.replace(',total:',',"total":')
        rs = rs.replace(',area:',',"area":')
        rs = rs.replace('{name:','{"name":')
        rs = rs.replace(',group:',',"group":')
        rs = rs.replace(',realm:',',"realm":')
        rs = rs.replace(',faction:',',"faction":')
        j = json.loads(rs)
    except Exception,ex:
        print '\n' + str(task_id) + ' ERROR JSON -> ',
        print Exception,':',ex
        return False

    if j['count'] > 0:
        for i in j['guilds']:
            try:
                if cursor_in.execute( sql_select % (i['name'],i['realm']) ) == 0:
                    cursor_in.execute( sql_in % (i['name'],i['total'],i['area'],i['group'],i['realm'],i['faction']) )
                    #print i['name'],'(new)',
                else:
                    #print i['name'],'(exist)',
                    pass;
            except Exception,ex:
                print '\n',str(task_id),' ERROR SQL -> ',
                print Exception,':',ex

        conn_in.commit()
        return True;
    else:
        return False;


def main():
    main_start = datetime.datetime.now()

    main_count = down_guild_sina_str()

    print '\n',datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S  '),str(main_count),' items OVER!'
    main_end = datetime.datetime.now()
    print '\n','USE Time : ',str(main_end - main_start)
    pass

if __name__ == '__main__':
    main()


