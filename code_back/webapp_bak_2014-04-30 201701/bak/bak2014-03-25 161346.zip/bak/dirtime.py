# -*- coding:UTF-8 -*-
import os,os.path
path = 'G:\\wowxxx\\webapp\\JSON\\'
files=[(os.path.getmtime(path+x),path+x) for x in os.listdir(path)]

print len(files)
print files[0][1]
print files[1][1]
print files[2][1]
print files[3][1]
print files[4][1]
