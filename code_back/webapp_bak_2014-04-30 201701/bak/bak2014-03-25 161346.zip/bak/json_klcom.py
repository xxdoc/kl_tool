# -*- coding: utf-8 -*-
import MySQLdb,json,os,logging,datetime,sys
   
def getdirsize(dir):
   size = 0L
   for root, dirs, files in os.walk(dir):
      size += sum([os.path.getsize(os.path.join(root, name)) for name in files])
   return size

def make_inti_dir(base_path_in ,*add_path_in):
    count_path = 0
    if len(add_path_in) == 0:
        return count_path;
    base_path = ''
    add_path = ''
    base_path = base_path_in
    if len(base_path.strip()) == 0:
        base_path = os.getcwd()
    for add_path in add_path_in:
        if isinstance(add_path,int):
            add_path = str(add_path)
        add_path = add_path.strip()
        if len(add_path) == 0:
            count_path = count_path + 100
            continue;
        else:
            base_path = base_path + '\\' + add_path
            if not os.path.isdir(base_path):
                if os.path.isfile(base_path):
                    os.remove(base_path)
                    count_path = count_path + 1000
                os.makedirs(base_path)
                count_path = count_path + 1
    return count_path;
   
def log_set(si):
   if len(si['filename'].strip())==0:
      si['filename'] = os.path.join(os.getcwd(), 'db_log.txt')
   if si['level']==0:
      si['level'] = 20
   if len(si['filemode'].strip())==0:
      si['filemode'] = 'a'
   if len(si['format'].strip())==0:
      si['format'] = '%(asctime)s - %(levelname)s: %(message)s'
   logging.basicConfig(filename = si['filename'], level = si['level'],\
                       filemode = si['filemode'], format = si['format'])

def dir_set(si):
   if len(si['base_path'].strip())==0:
      si['base_path'] = os.getcwd()
   if len(si['JSON_path'].strip())==0:
      si['JSON_path'] = 'JSON'
   if len(si['DATA_TEMP_path'].strip())==0:
      si['DATA_TEMP_path'] = 'DATA_TEMP'
   if len(si['DATA_BAK_path'].strip())==0:
      si['DATA_BAK_path'] = 'DATA_BAK'
   rd = make_inti_dir(si['base_path'],si['JSON_path'],si['DATA_TEMP_path'],si['DATA_BAK_path'])
   if rd>0 :
      print 'Make Dir by make_inti_dir(), return :' + str(rd)


def ah_json_mysql(fwq_name, conn, cursor, base_path = os.getcwd(), \
                  JSON_path = 'JSON', DATA_TEMP_path = 'DATA_TEMP', DATA_BAK_path = 'DATA_BAK', \
                  ah_tmp = 'aaa_ah_tmp', fwq_tmp = 'aaa_fwq_tmp', bak_size_limt = 100, db = 'wow_ah_db'):
   
   if not isinstance(fwq_name, str):
      cfg_file = repr(fwq_name)
   fwq_name = fwq_name.lower()
   if len(fwq_name.strip()) == 0:
      return -99;
   
   print "De AH json ing..."
   if len(base_path.strip()) == 0:
      base_path = os.getcwd()
   json_dir = base_path + '\\' + JSON_path
   temp_dir = json_dir + '\\' + DATA_TEMP_path
   bak_dir = temp_dir + '\\' + DATA_BAK_path
   file_path = ''.join([json_dir,'\\',fwq_name,'.json'])
   if os.path.isfile(file_path):
      file_size = os.path.getsize(file_path)
      if file_size>128:
         logging.info('js JSON: done >> ' + file_path)
         dff = file(file_path)
         dfj = json.load(dff)
         dff.close()
      else:
         logging.info('js Error: x_file >> ' + file_path + ' (-10)')
         return -10;
   else:
      logging.info('js Error: no file >> ' + file_path + ' (-11)')
      return -11;

   ah_file_url = dfj["files"][0]["url"]
   ah_file_last = dfj["files"][0]["lastModified"]
   ah_file_name = ''.join([fwq_name,'_',str(ah_file_last),'.json'])
   ah_file_path = temp_dir + '\\' + ah_file_name
   ah_file_size = 0

   if os.path.isfile(ah_file_path):
      ah_file_size = os.path.getsize(ah_file_path)
      if ah_file_size>128:
         logging.info('db JSON: done >> ' + ah_file_path)
         ahf = file(ah_file_path)
         ahj = json.load(ahf)
         ahf.close()
      else:
         logging.info('db Error: x_file >> ' + ah_file_path + ' (-12)')
         return -12;
   else:
      if os.path.isfile(ah_file_path + '.td'):
         logging.info('db Error: Downing file >> ' + ah_file_path + ' (-23)')
         return -23;
      ah_file_path = bak_dir + '\\' + ah_file_name
      if os.path.isfile(ah_file_path):
         logging.info('db Error: Bakup file >> ' + ah_file_path + ' (-33)')
         return -33;        
      logging.info('db Error: no file >> ' + ah_file_path + ' (-13)')
      return -13;
   
   ac = len(ahj["alliance"]["auctions"])
   hc = len(ahj["horde"]["auctions"])
   nc = len(ahj["neutral"]["auctions"])
   cc = ac + hc + nc
   if cc == 0:
      print "Error : count >> " ,ac,hc,nc,cc
      logging.info('db Error: no count >> 0 (-14)')
      return -14;
   if len(ahj["realm"]["name"].strip()) == 0:
      print "Error : fwq_name >> " ,ahj["realm"]["name"]
      logging.info('db Error: no name >> xxxxx (-15)')
      return -15;

   fwq_name = ahj["realm"]["slug"].lower()
   
   
   setsql = 'select table_name from information_schema.tables where table_name = \"' + fwq_name + '\" and table_schema=\"' + db +'\"'
   if cursor.execute (setsql) ==1:
      setsql = 'drop table if exists ' + fwq_name
      cursor.execute (setsql)
      conn.commit()
   
   setsql = 'create table if not exists ' + fwq_name + ' like ' + ah_tmp
   cursor.execute (setsql)
   conn.commit()
   
   print "Updata ing... >> alliance"
   logging.info('db MySQL: updata >> alliance')
   
   ah_from = "alliance"
   sql1 = "INSERT into " + fwq_name + " values('%s','%s','%s','%s','%s','%s','%s','%s','%s',0,0,0,0,0,'%s')"
   sql2 = "INSERT into " + fwq_name + " values('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s',1,'%s')"
   for i in ahj[ah_from]["auctions"]:
      k_len = len(i)
      if k_len ==9:
         n=cursor.execute(sql1%(i["auc"],i["item"],i["owner"],i["bid"],i["buyout"],i["quantity"],i["timeLeft"],i["rand"],i["seed"],ah_from))
      elif k_len ==13:
         n=cursor.execute(sql2%(i["auc"],i["item"],i["owner"],i["bid"],i["buyout"],i["quantity"],i["timeLeft"],i["rand"],i["seed"],\
                                i["petSpeciesId"],i["petBreedId"],i["petLevel"],i["petQualityId"],ah_from))
      else:
         continue;
     
   logging.info('db MySQL: updata >> horde')
   print "Updata ing... >> horde"
   conn.commit()
   ah_from = "horde"
   sql1 = "INSERT into " + fwq_name + " values('%s','%s','%s','%s','%s','%s','%s','%s','%s',0,0,0,0,0,'%s')"
   sql2 = "INSERT into " + fwq_name + " values('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s',1,'%s')"
   for i in ahj[ah_from]["auctions"]:
      k_len = len(i)
      if k_len ==9:
         n=cursor.execute(sql1%(i["auc"],i["item"],i["owner"],i["bid"],i["buyout"],i["quantity"],i["timeLeft"],i["rand"],i["seed"],ah_from))
      elif k_len ==13:
         n=cursor.execute(sql2%(i["auc"],i["item"],i["owner"],i["bid"],i["buyout"],i["quantity"],i["timeLeft"],i["rand"],i["seed"],\
                                i["petSpeciesId"],i["petBreedId"],i["petLevel"],i["petQualityId"],ah_from))
      else:
         continue;

   print "Updata ing... >> neutral"
   logging.info('db MySQL: updata >> neutral')
   conn.commit()
   ah_from = "neutral"
   sql1 = "INSERT into " + fwq_name + " values('%s','%s','%s','%s','%s','%s','%s','%s','%s',0,0,0,0,0,'%s')"
   sql2 = "INSERT into " + fwq_name + " values('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s',1,'%s')"
   for i in ahj[ah_from]["auctions"]:
      k_len = len(i)
      if k_len ==9:
         n=cursor.execute(sql1%(i["auc"],i["item"],i["owner"],i["bid"],i["buyout"],i["quantity"],i["timeLeft"],i["rand"],i["seed"],ah_from))
      elif k_len ==13:
         n=cursor.execute(sql2%(i["auc"],i["item"],i["owner"],i["bid"],i["buyout"],i["quantity"],i["timeLeft"],i["rand"],i["seed"],\
                                i["petSpeciesId"],i["petBreedId"],i["petLevel"],i["petQualityId"],ah_from))
      else:
         continue;
     
   conn.commit()
   logging.info('db MySQL: updata >> fwq_info')
   print "Updata ing... >> fwq_info"

   ahj["realm"]["name"] = ahj["realm"]["name"].replace("\'","\\\'")
   ah_file_path2 = ah_file_path.replace("\\","\\\\")
   ah_file_path2 = ah_file_path2.replace("\'","\\\'")
   now = datetime.datetime.now().strftime("%y-%m-%d %H:%M:%S")
   sql1 = "replace into fwq_info (name,slug,fsize,last,time,url,dir,count,counta,counth,countn) \
                     values('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')"
   n=cursor.execute(sql1%(ahj["realm"]["name"],ahj["realm"]["slug"],ah_file_size,\
                     ah_file_last,now,ah_file_url,ah_file_path2,cc,ac,hc,nc))
   conn.commit()

   if os.path.getsize(ah_file_path) < bak_size_limt * 1024 * 1024:
      bak_file_path = bak_dir + '\\' + ah_file_name
      if os.path.isfile(bak_file_path):
         os.remove(bak_file_path)
      os.rename(ah_file_path, bak_file_path)
      if os.path.isfile(ah_file_path):
         os.remove(ah_file_path)
   else:
       if os.path.isfile(ah_file_path):
         os.remove(ah_file_path)     
         
   logging.info('bak JSON: move file >> ' + fwq_name)
   print "Bakup JSON file"
   bak_file_path = bak_dir + '\\'
   bak_size = getdirsize(bak_file_path)
   print "Bakup Size : " + str(bak_size)
   logging.info('bak JSON: bakup size >> ' + str(bak_size))
   if bak_size > bak_size_limt * 1024 * 1024 :
      print "Bakup Out : " + str(bak_size) + '/' + str(bak_size_limt)
      logging.info('bak JSON: bakup Out >> ' + str(bak_size))
      files=[(os.path.getmtime(bak_file_path+x),bak_file_path+x) for x in os.listdir(bak_file_path)]
      os.remove(files[0][1])
      print "Bakup Del : " + files[0][1]
      logging.info('bak JSON: bakup Del >> ' + files[0][1])
     
   logging.info('db MySQL: done >> ' + fwq_name)
   print "Done"
   return cc;

def json_main(cfg_file):
   logging.basicConfig(filename = os.path.join(os.getcwd(), 'base_log.txt'), \
    level = logging.INFO, filemode = 'a', format = '%(asctime)s - %(levelname)s: %(message)s')
   
   if not isinstance(cfg_file, str):
      cfg_file = repr(cfg_file)
   if cfg_file.find(':') <= 0:
      cfg_file = os.path.join(os.getcwd(), cfg_file )
   if os.path.isfile(cfg_file):
     file_size = os.path.getsize(cfg_file)
     if file_size>128:
         logging.info('cfg JSON: done >> ' + cfg_file)
         file_object = open(cfg_file,'r')
         file_object.seek(3)
         try:
            all_the_text = file_object.read( )
         finally:
            file_object.close( )
         if isinstance(all_the_text, unicode):
            all_the_text.encode("utf-8")
         dfj = json.loads(all_the_text)
     else:
         logging.error('cfg Error: x_file >> ' + cfg_file + ' (-10)')
         return -10;
   else:
     logging.error('cfg Error: no file >> ' + cfg_file + ' (-11)')
     return -11;

   print 'Done JSON file : ' + cfg_file
   logging.info('cfg INFO: Done JSON>> ' + cfg_file)
   
   test_str = "base_path,cfg_file,JSON_path,DATA_TEMP_path,DATA_BAK_path,bak_size_limt,help"
   split_str = test_str.split(',')
   test_str = 'base_set'
   
   if dfj.has_key(test_str):
      for i in split_str:
         if dfj[test_str].has_key(i):
            pass;
         else:
            logging.error('cfg Error: no ' + i + ' in ' + test_str + ' >> ' + cfg_file + ' (-12)')
            return -12;
   else:
      logging.error('cfg Error: no ' + test_str + ' >> ' + cfg_file + ' (-13)')
      return -13;
   test_str = "host,user,passwd,db,charset,ah_tmp,fwq_tmp,help"
   split_str = test_str.split(',')
   test_str = 'MySQL_set'
   if dfj.has_key(test_str):
      for i in split_str:
         if dfj[test_str].has_key(i):
            pass;
         else:
            logging.error('cfg Error: no ' + i + ' in ' + test_str + ' >> ' + cfg_file + ' (-12)')
            return -12;
   else:
      logging.error('cfg Error: no ' + test_str + ' >> ' + cfg_file + ' (-13)')
      return -13;
   test_str = "filename,level,filemode,format,help"
   split_str = test_str.split(',')
   test_str = 'log_set'
   if dfj.has_key(test_str):
      for i in split_str:
         if dfj[test_str].has_key(i):
            pass;
         else:
            logging.error('cfg Error: no ' + i + ' in ' + test_str + ' >> ' + cfg_file + ' (-12)')
            return -12;
   else:
      logging.error('cfg Error: no ' + test_str + ' >> ' + cfg_file + ' (-13)')
      return -13;
   
   if dfj.has_key('task'):
      if dfj['task'].has_key('info'):
         if len(dfj['task']['info']) > 0:
            for i in dfj['task']['info']:
               if i.has_key('is') and i.has_key('name'):
                  pass;
               else:
                  logging.error('cfg Error: error task info >> ' + cfg_file + ' (-16)')
                  return -16;
            print 'Task Count :' + str(len(dfj['task']['info']))
            logging.info('cfg INFO: task count : ' + str(len(dfj['task']['info'])) + ' >> ' + cfg_file)
         else:
            logging.error('cfg Error: task count is 0 >> ' + cfg_file + ' (-17)')
            return -17;
      else:
         logging.error('cfg Error: no task info >> ' + cfg_file + ' (-15)')
         return -15;
   else:
      logging.error('cfg Error: no task >> ' + cfg_file + ' (-14)')
      return -14;

   dir_set(dfj['base_set'])
   bs = dfj['base_set']   
   si = dfj['MySQL_set']
   if len(si['host'].strip())==0:
      si['host'] = "localhost"
   if len(si['user'].strip())==0:
      si['user'] = "root"
   if len(si['passwd'].strip())==0:
      si['passwd'] = "123"
   if len(si['db'].strip())==0:
      si['db'] = "wow_ah_db"
   if len(si['charset'].strip())==0:
      si['charset'] = "utf8"
   if len(si['ah_tmp'].strip())==0:
      si['ah_tmp'] = "aaa_ah_tmp"
   if len(si['fwq_tmp'].strip())==0:
      si['fwq_tmp'] = "aaa_fwq_tmp"

   print "Link ing... >> MySQL"
   logging.info('db MySQL: link >> ' + si['db'])
   
   conn_i = MySQLdb.connect(host=si['host'],user=si['user'],passwd=si['passwd'],db=si['db'],charset=si['charset'])
   cursor_i = conn_i.cursor()
   setsql = 'set names "utf8"'
   cursor_i.execute (setsql)
   
   setsql = 'select table_name from information_schema.tables where table_name = "fwq_info" and table_schema=\"' + si['db']+'\"'
   if cursor_i.execute (setsql) ==0:
      setsql = 'create table if not exists fwq_info like ' + si['fwq_tmp']
      cursor_i.execute (setsql)
   conn_i.commit()
   
   log_set(dfj['log_set'])

   t_count = 0
   for i in dfj['task']['info']:
      fwq_name_i = i["name"].lower()
      if i["is"] == 1:
         print '------------------------' + fwq_name_i + '------------------------'
         rd = ah_json_mysql(fwq_name_i, conn_i, cursor_i, base_path = bs['base_path'], \
                  JSON_path = bs['JSON_path'], DATA_TEMP_path = bs['DATA_TEMP_path'], DATA_BAK_path = bs['DATA_BAK_path'], \
                  ah_tmp = si['ah_tmp'], fwq_tmp = si['fwq_tmp'], bak_size_limt = bs['bak_size_limt'],db = si['db'])
         if rd <=0 :
            print fwq_name_i + ' -> ah_json_mysql  ERROR : ' + str(rd)
         else:
            t_count = t_count + 1
            print fwq_name_i + ' -> ah_json_mysql  DONE : ' + str(rd)

   conn_i.commit()
   cursor_i.close()
   conn_i.close()

   return t_count


if __name__=='__main__':
   print sys.argv[0] + " >>"
   cfg = ''
   if len(sys.argv) == 1 :
      cfg = 'wow_ah.cfg'
   elif len(sys.argv[1].strip())== 0 or not os.path.isfile(sys.argv[1].strip()):
      cfg = 'wow_ah.cfg'
   else:
      cfg = sys.argv[1].strip()
   print json_main(cfg)


print 'OVER'

