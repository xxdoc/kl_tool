import sys,MySQLdb,json,os,datetime,urllib2

base_cfg = ''.join(['{\"base_set\":{\"base_path\":\"\",\"cfg_file\":\"wow_ah.cfg\",\"JSON_path\":\"JSON\",\"DATA_TEMP_pat',\
                      'h\":\"DATA_TEMP\",\"DATA_BAK_path\":\"DATA_BAK\",\"bak_size_limt\":100},\"MySQL_set\":{\"host\":\"lo',\
                      'calhost\",\"user\":\"root\",\"passwd\":\"root\",\"db\":\"wow_ah_db\",\"charset\":\"utf8\",\"port\":3306,\"ah_tmp\":\"a',\
                      'aa_ah_tmp\",\"fwq_tmp\":\"aaa_fwq_tmp\"},\"log_set\":{\"filename\":\"db_log.txt\",\"level\":20,\"filemo',\
                      'de\":\"a\",\"format\":\"%(asctime)s - %(levelname)s: %(message)s\"}}'])

bfj = json.loads(base_cfg)

file_object = open('status.json','r')
file_object.seek(3)
try:
    all_the_text = file_object.read()
finally:
    file_object.close()
if isinstance(all_the_text, unicode):
    all_the_text.encode("utf-8")
sfj = json.loads(all_the_text)


main_url = r'http://www.battlenet.com.cn/api/wow/realm/status'

re = urllib2.Request(main_url)
rs = urllib2.urlopen(re).read()
drj = json.loads(rs)

si = bfj['MySQL_set']
print si
print "Link ing... >> MySQL"

conn = MySQLdb.connect(host='127.0.0.1',user=si['user'],passwd=si['passwd'],db=si['db'],charset=si['charset'],port=3306)


cursor = conn.cursor()

setsql = 'set names "utf8"'
cursor.execute (setsql)

start = datetime.datetime.now()
sql1 = "replace into aa_fwq_status_a (zname,battlegroup,population,type,queue) \
                 values('%s','%s','%s','%s','%s')"
for i in range(1):
    for i in sfj["realms"]:
        cursor.execute(sql1%(i["name"],i['battlegroup'],i['population'],i['type'],i['queue']))
conn.commit()
end = datetime.datetime.now()
print end - start


start = datetime.datetime.now()
sql1 = "replace into aa_fwq_status_a (zname,battlegroup,population,type,queue) values"
for i in range(1):
	pass;
    #cursor.executemanyklex(sql1,sfj["realms"],['name','battlegroup','population','type','queue'])
    
conn.commit()
end = datetime.datetime.now()
print end - start


#name battlegroup  population type queue
#now = datetime.datetime.now().strftime("%y-%m-%d %H:%M:%S")



cursor.close()
conn.close()


print 'over!'
