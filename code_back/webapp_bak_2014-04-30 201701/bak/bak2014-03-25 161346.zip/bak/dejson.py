import json,urllib2,os,web,win32con,win32api,time
#db = web.database(dbn='mysql', user='user', pw='pass', db='dbname')
import win32com.client  
import logging

logging.basicConfig(filename = os.path.join(os.getcwd(), 'log.txt'), \
    level = logging.INFO, filemode = 'a', format = '%(asctime)s - %(levelname)s: %(message)s')
#logging.debug('debug')
#logging.info('info')
#logging.warning('warn')
#logging.error('error')

is_try_download = False


fwq_name = 'medivh'
main_url = r'http://www.battlenet.com.cn/api/wow/auction/data/' + fwq_name

file_patch = ''.join([os.getcwd(),'\\JSON\\',fwq_name,'.json'])
re = urllib2.Request(main_url)
rs = urllib2.urlopen(re).read()
logging.info('df GET: ' + fwq_name)
drj = json.loads(rs)

ah_file_last = drj["files"][0]["lastModified"]
ah_file_url = drj["files"][0]["url"]
ah_file_name = ''.join([fwq_name,'_',str(drj["files"][0]["lastModified"]),'.json'])
ah_file_path = os.getcwd() + '\\JSON\\DATA_TEMP\\' + ah_file_name

if os.path.isfile(file_patch):
    dff = open(file_patch,'w+')
else:
    dff = open(file_patch,'w')
    
if os.path.getsize(file_patch) >128:
    dfj = json.load(dff)
    if drj["files"][0]["lastModified"] > dfj["files"][0]["lastModified"] :
        logging.info('df UPDATA: ' + fwq_name + str(ah_file_last))
        dff.write(rs)
        is_try_download = True
        logging.info('ah TRYDOWN: ' + fwq_name + str(ah_file_last))
else:
    logging.info('df INIT: ' + fwq_name)
    dff.write(rs)
    is_try_download = True
    logging.info('ah TRYDOWN: ' + fwq_name + str(ah_file_last))
dff.flush()
dff.close

print drj["files"][0]["lastModified"]
print ah_file_last
print is_try_download

if not os.path.isfile(ah_file_path):
    is_try_download = True

print drj["files"][0]["lastModified"]
print ah_file_last
print is_try_download

if os.path.isfile(os.getcwd() + '\\JSON\\DATA_TEMP\\DATA_BAK\\' + ah_file_name) or \
   os.path.isfile(ah_file_path + '.td'):
    is_try_download = False

print drj["files"][0]["lastModified"]
print ah_file_last
print is_try_download

dm = win32com.client.Dispatch('dm.dmsoft')  
ThunderAgent = win32com.client.Dispatch("ThunderAgent.Agent")
if is_try_download:
    ThunderAgent.AddTask(ah_file_url, ah_file_name ,os.getcwd() + '\\JSON\\DATA_TEMP',"","",1,0,5) 
    ThunderAgent.CommitTasks2(1)
    win32api.Sleep(300)
    dm.KeyPress(13)
    logging.info('ah DOWNLOAD: ' + fwq_name + str(ah_file_last)) 
    is_try_download = False
    







