<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php
echo "<head>\n";
echo "<meta http-equiv='Content-Type' content='text/html; charset=utf8' />\n";
echo "<title>123</title>\n";
echo "</head>\n";
echo "<pre>\n";

$tcp = uv_tcp_init();
uv_tcp_bind($tcp, uv_ip4_addr('0.0.0.0',3000));
uv_listen($tcp,100, function($server){
    $client = uv_tcp_init();
    uv_accept($server, $client);
    uv_read_start($client, function($socket, $nread, $buffer) use ($server){
        echo $buffer . PHP_EOL;
        uv_close($socket);
        uv_close($server,function() use ($server){
            uv_unref($server);
        });
    });
});

$addrinfo = uv_tcp_getsockname($tcp);

$c = uv_tcp_init();
uv_tcp_connect($c, uv_ip4_addr($addrinfo['address'],$addrinfo['port']), function($client, $stat){
    if ($stat == 0) {
        uv_write($client,"Hello",function($socket, $stat){
            uv_close($socket,function(){});
        });
    }
});

uv_run();

echo "run!!!";
?>