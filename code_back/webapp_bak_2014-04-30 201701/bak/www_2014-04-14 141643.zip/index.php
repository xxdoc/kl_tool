<?php
class MyShowDir {
	
	private $path = '';
	private $url = '';
	private $fcode = '';
	private $deep = 0;
	private $index = null;
	
	function __construct($path_in, $fcode_in, $url_in , $deep_in) {
		$this->path = $path_in;
		$this->url = $url_in;
		$this->deep = $deep_in;
		$this->fcode = $fcode_in;
		$this->index = array (
				'index.php',
				'index.html',
				'index.asp',
				'index.jsp' 
		);
	}
	
	public function ShowDir() {
		echo $this->MakeDirHtml ( $this->path, $this->deep, '' );
	}
	
	private function MakeDirHtml($path, $deep_in, $tab_in) {
		$file_array = array ();
		$dir_array = array ();
		if ($deep_in < 1 || ! is_dir ( $path ) || ! ($current_dir = opendir ( $path ))) {
			return '';
		}
		while ( ($file = readdir ( $current_dir )) !== false ) {
			if ($file == '.' || $file == '..') {
				continue;
			} else if (is_dir ( $path . $file . '/' )) {
				$dir_array [] = $file;
			} else {
				$file_array [] = $file;
			}
		}
		
		sort ( $dir_array );
		sort ( $file_array );
		$print_str = '';
		$tabs = $tab_in . '&emsp;&emsp;';
		foreach ( $dir_array as $file ) {
			$sub_d = $path . $file . '/';
			$sub_dir = urlencode ( $sub_d );
			if ($this->isIndexDir ( $this->index, $sub_d )) {
				$print_str .= "<li>$tab_in<a href='$sub_d'>$file</a>&emsp;&nbsp;<a href='$this->url?dir=$sub_dir'>【目录】</a></li>\n";
			} else {
				$print_str .= "<li>$tab_in$file&nbsp;&nbsp;<a href='$this->url?dir=$sub_dir'>【目录】</a></li>\n";
			}
			if ($deep_in - 1 > 0) {
				$print_str .= $this->MakeDirHtml ( $sub_d, $deep_in - 1, $tabs );
			}
		}
		$print_str .= "<br />$tabs---------------------------------------<br />\n";
		foreach ( $file_array as $file ) {
			$sub_d = $path . $file;
			$sub_dir = urlencode ( $sub_d );
			$print_str .= $tabs . "<a href='$this->url?act=edit&dir=$sub_dir'><small>[edit]</small></a>";
			$print_str .= "<a href='$this->url?act=view&dir=$sub_dir'><small>[view]</small></a>&nbsp;<a href='$sub_d'>$file</a><br />\n";
		}
		$print_str .= "$tabs---------------------------------------\n";
		return $print_str;
	}
	
	private function isIndexDir($array_in, $dir_in) {
		if (! is_dir ( $dir_in ) || ($current_dir = opendir ( $dir_in )) == false) {
			return false;
		}
		while ( ($file = readdir ( $current_dir )) != false ) {
			if ($file == '.' || $file == '..') {
				continue;
			}
			foreach ( $array_in as $index ) {
				if ($index == $file && is_file ( $dir_in . $file )) {
					return true;
				}
			}
		}
		return false;
	}
	
	public function ShowFile() {
		// show_source($this->path);
		$my_file = file_get_contents ( $this->path );
		if ($this->fcode == 'gb2312') {
			$my_file = iconv ( "gb2312", "UTF-8//IGNORE", $my_file );
		}
		highlight_string ( $my_file );
	}
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php
define("INDEX_PATH", basename($_SERVER['PHP_SELF']));

$get_dir = (array_key_exists ( 'dir', $_GET )) ? (urldecode ( $_GET ['dir'] )) : ('./');
$get_act = (array_key_exists ( 'act', $_GET )) ? ($_GET ['act']) : ('dir');
$get_deep = (array_key_exists ( 'deep', $_GET )) ? ($_GET ['deep']) : (1);
$get_charset = (array_key_exists ( 'charset', $_GET )) ? ($_GET ['charset']) : ('utf8');
$get_fcode = (array_key_exists ( 'fcode', $_GET )) ? ($_GET ['fcode']) : ('utf8');
$up_dir = substr ( $get_dir, 0, ($tp = strrpos ( substr ( $get_dir, 0, - 1 ), '/' )) ? ($tp) : (1) ) . '/';

$dir_obj = new MyShowDir ( $get_dir, $get_fcode, constant("INDEX_PATH"), $get_deep );

echo "<meta http-equiv='Content-Type' content='text/html; charset=$get_charset' />";
echo "<title>$get_act>>$get_dir</title>\n";
?>
</head>
<body>
	<div align="center">
		<table border="0" cellpadding="3" width="600" align="center">
			<tr>
			<?php
			echo "<div align='center'><a href='".constant("INDEX_PATH")."?dir=" . urlencode ( $up_dir ) . "' />UpDir</a>&emsp;&emsp;";
			if ($get_dir == './') {
				echo "<a href='".constant("INDEX_PATH")."?act=phpinfo' />PHPVer</a>&emsp;&emsp;<a href='test.php' />TEST</a>&emsp;&emsp;";
			}
			echo "<a href='".constant("INDEX_PATH")."' />Home</a></div>";
			?>
			</tr>
		</table>
	</div>
	<br />
	<br />
	<br />
<?php
switch ($get_act) {
	case "dir" :
		echo "<table width='600' align='center'><tr>";
		$dir_obj->ShowDir ();
		echo "</tr></table>";
		break;
	case "phpinfo" :
		phpinfo ();
		break;
	case "view" :
		echo "<div align='center'><a href='".constant("INDEX_PATH")."?act=view&fcode=utf8&dir=" . urlencode ( $get_dir ) . "' />UTF-8</a>";
		echo "&emsp;&emsp;<a href='".constant("INDEX_PATH")."?act=view&fcode=gb2312&dir=" . urlencode ( $get_dir ) . "' />GB2312</a>";
		echo "</div><br /><br /><br /><pre>";
		$dir_obj->ShowFile ();
		echo "</pre>";
		break;
}
?>
</body>
</html>