<?php /* Smarty version Smarty-3.1.16, created on 2014-03-22 19:25:42
         compiled from ".\html\common_header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:30054531455c84e42f9-88105139%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2987dcb6ca52d283542b7a669d459e0eb28e93d6' => 
    array (
      0 => '.\\html\\common_header.tpl',
      1 => 1395487535,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '30054531455c84e42f9-88105139',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_531455c84e84a0_38008595',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_531455c84e84a0_38008595')) {function content_531455c84e84a0_38008595($_smarty_tpl) {?>		<div id="header">
			<div class="search-bar">
				<form action="" method="get" autocomplete="off">
					<div>
						<input type="text" class="search-field input" name="q"
							id="search-field" maxlength="200" tabindex="40" alt="搜索其他信息…"
							value="搜索其他信息…" />
						<input type="submit" class="search-button" value="" tabindex="41" />
					</div>
				</form>
			</div>
			<h1 id="logo">
				<a href="">《魔兽世界®》</a>
			</h1>
			<div class="header-plate">
				<ul class="menu" id="menu">
					<li class="menu-home" itemscope="itemscope"
						itemtype="http://schema.org/SiteNavigationElement">
						<a itemprop="url" href="">
							<span itemprop="name">主页</span>
						</a>
					</li>
					<li class="menu-game" itemscope="itemscope"
						itemtype="http://schema.org/SiteNavigationElement">
						<a itemprop="url" href="" class="menu-active">
							<span itemprop="name">游戏指南</span>
						</a>
					</li>
					<li class="menu-community" itemscope="itemscope"
						itemtype="http://schema.org/SiteNavigationElement">
						<a itemprop="url" href="">
							<span itemprop="name">社区</span>
						</a>
					</li>
					<li class="menu-media" itemscope="itemscope"
						itemtype="http://schema.org/SiteNavigationElement">
						<a itemprop="url" href="">
							<span itemprop="name">媒体</span>
						</a>
					</li>
					<li class="menu-forums" itemscope="itemscope"
						itemtype="http://schema.org/SiteNavigationElement">
						<a itemprop="url" href="">
							<span itemprop="name">论坛</span>
						</a>
					</li>
					<li class="menu-services" itemscope="itemscope"
						itemtype="http://schema.org/SiteNavigationElement">
						<a itemprop="url" href="">
							<span itemprop="name">服务</span>
						</a>
					</li>
				</ul>
				<div class="user-plate">
					<a href="#login" class="card-character plate-logged-out" onclick="">
						<span class="card-portrait"></span>
						<span class="wow-login-key"></span>
						<span class="login-msg">
							<strong>登录</strong>
							发表评论并对您的站点内容进行个性化设置。
						</span>
					</a>
				</div>
			</div>
		</div><?php }} ?>
