<?php /* Smarty version Smarty-3.1.16, created on 2014-03-22 14:20:48
         compiled from ".\html\common_footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:6484531455c86ad701-28019938%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '835e188c5c8931b1601d4bc79e269cd2bb22f2a7' => 
    array (
      0 => '.\\html\\common_footer.tpl',
      1 => 1395469242,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '6484531455c86ad701-28019938',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_531455c86b2743_21033739',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_531455c86b2743_21033739')) {function content_531455c86b2743_21033739($_smarty_tpl) {?>		<div id="footer">
			<div class="lower-footer-wrapper">
				<div class="lower-footer">
					<div id="copyright">
						<div class="footer-logo">
							<a target="_blank" href="http://www.blizbliz.com" tabindex="100">
								<img src="./img/blizz-wow.png" alt="" />
							</a>
							<a rel="nofollow" target="_blank" href="http://www.666.com"
								tabindex="100">
								<img class="logo-netease" src="./img/flogo-netease.gif" alt="" />
							</a>
						</div>
						<div class="legal">
							©2014 AAA娱乐股份有限公司版权所有 由XXX网络科技发展有限公司运营
							<a target="_blank" class="footer-link"
								href=".\fwq.html">著作权侵权</a>
							<a target="_blank" class="footer-link"
								href=".\README.html">技术支持</a>
							<br />
							文网进字[2012]033号
							<a target="_blank" class="footer-link"
								href="http://www.baidu.com/"
								tabindex="100">沪网文[2011]0682-074号</a>
							<a rel="nofollow" target="_blank" class="footer-link"
								href="http://www.miitbeian.gov.cn/state/outPortal/loginPortal.action"
								tabindex="100">增值电信业务经营许可证编号：沪B2－20080012</a>
							<a target="_blank" href="http://www.baidu.com/"
								tabindex="100">法律文件</a>
							<br />
							新出审字：[2012]712号
							<a href="mailto:wlyxjb@gmail.com" tabindex="100">文化部网络游戏举报与联系邮箱：wlyxjb@gmail.com</a>
							<a target="_blank"
								href="http://www.baidu.com/"
								tabindex="100">《互联网文化管理暂行规定》</a>
						</div>
						<p style="clear: both;"></p>
						<div class="notices">
							积极健康的游戏心态是健康游戏的开端，请您合理控制游戏时间，避免沉溺游戏影响生活，注意自我保护，防范网络陷阱。
							<br />
							健康游戏忠告：抵制不良游戏，拒绝盗版游戏。注意自我保护，谨防受骗上当。适度游戏益脑，沉迷游戏伤身。合理安排时间，享受健康生活。
						</div>
					</div>
					<div id="marketing-trackers">
						<div class="marketing-cover"></div>
					</div>
				</div>
			</div>
		</div><?php }} ?>
