<?php /* Smarty version Smarty-3.1.16, created on 2014-03-17 20:19:01
         compiled from ".\html\web_auction.html" */ ?>
<?php /*%%SmartyHeaderCode:748253265425533223-95642344%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2dd258a32f6dcc7c38ddc946256f226bf46886e2' => 
    array (
      0 => '.\\html\\web_auction.html',
      1 => 1395058732,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '748253265425533223-95642344',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_53265425803177_31873589',
  'variables' => 
  array (
    'baseSet' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_53265425803177_31873589')) {function content_53265425803177_31873589($_smarty_tpl) {?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="zh-cn" class="zh-cn chrome chrome17">
<head xmlns:og="http://ogp.me/ns#" xmlns:fb="http://ogp.me/ns/fb#">
	<meta http-equiv="imagetoolbar" content="false" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title>浏览拍卖 - 社区 - 魔兽世界</title>
	<link rel="stylesheet" type="text/css" media="all"
		href="<?php echo $_smarty_tpl->tpl_vars['baseSet']->value['path_css'];?>
\profile.css?v=37" />
	<link rel="stylesheet" type="text/css" media="all"
		href="<?php echo $_smarty_tpl->tpl_vars['baseSet']->value['path_css'];?>
\pet.css?v=37" />
	<link rel="stylesheet" type="text/css" media="all"
		href="<?php echo $_smarty_tpl->tpl_vars['baseSet']->value['path_css'];?>
\auction.css?v=37" />
	<!--[if IE]>
		<link rel="stylesheet" type="text/css" media="all" href="<?php echo $_smarty_tpl->tpl_vars['baseSet']->value['path_css'];?>
\wow-ie.css?v=37" />
	<![endif]-->
	<!--[if IE 6]>
		<link rel="stylesheet" type="text/css" media="all" href="<?php echo $_smarty_tpl->tpl_vars['baseSet']->value['path_css'];?>
\wow-ie6.css?v=37" />
	<![endif]-->
	<!--[if IE 7]>
		<link rel="stylesheet" type="text/css" media="all" href="<?php echo $_smarty_tpl->tpl_vars['baseSet']->value['path_css'];?>
\wow-ie7.css?v=37" />
	<![endif]-->
	<!--[if IE]>
		<link rel="stylesheet" type="text/css" media="all" href="<?php echo $_smarty_tpl->tpl_vars['baseSet']->value['path_css'];?>
\profile-ie.css?v=37" />
	<![endif]-->
	<!--[if IE 6]>
		<link rel="stylesheet" type="text/css" media="all" href="<?php echo $_smarty_tpl->tpl_vars['baseSet']->value['path_css'];?>
\auction-ie6.css?v=37" />
	<![endif]-->
	<!--[if IE 6]>
		<link rel="stylesheet" type="text/css" media="all" href="<?php echo $_smarty_tpl->tpl_vars['baseSet']->value['path_css'];?>
\profile-ie6.css?v=37" />
	<![endif]-->
	<!--[if IE 6]>
		<link rel="stylesheet" type="text/css" media="all" href="<?php echo $_smarty_tpl->tpl_vars['baseSet']->value['path_css'];?>
\pet-ie6.css?v=37" />
	<![endif]-->
	<link rel="shortcut icon" href="favicon.ico?v=58-37" />
	<link rel="stylesheet" type="text/css" media="all"
		href="<?php echo $_smarty_tpl->tpl_vars['baseSet']->value['path_css'];?>
\common-game-site.css?v=58-37" />
	<link rel="stylesheet" type="text/css" media="all"
		href="<?php echo $_smarty_tpl->tpl_vars['baseSet']->value['path_css'];?>
\wow.css?v=37" />
	<link rel="stylesheet" type="text/css" media="all"
		href="<?php echo $_smarty_tpl->tpl_vars['baseSet']->value['path_css'];?>
\lightbox.css?v=37" />
	<link rel="stylesheet" type="text/css" media="all"
		href="<?php echo $_smarty_tpl->tpl_vars['baseSet']->value['path_css'];?>
\realmstatus.css?v=37" />
	<link rel="stylesheet" type="text/css" media="all"
		href="<?php echo $_smarty_tpl->tpl_vars['baseSet']->value['path_css'];?>
\zh-cn.css?v=37" />
	<link rel="stylesheet" type="text/css" media="all"
		href="<?php echo $_smarty_tpl->tpl_vars['baseSet']->value['path_css'];?>
\ratings.css?v=58-37" />
	<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['baseSet']->value['path_js'];?>
\third-party.js?v=58-37" /></script>
	<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['baseSet']->value['path_js'];?>
\common-game-site.js?v=58-37" /></script>
</head>
<body class="zh-cn">
	<div id="wrapper">
	<script type="text/javascript">
		//<![CDATA[
		var xsToken = '';
		var supportToken = '';
		var jsonSearchHandlerUrl = '//www.battlenet.com.cn';
		var Msg = Msg || {};
		Msg.support = {
			ticketNew: '表单{0}已被建立。',
			ticketStatus: '表单{0}的状态已变更为为{1}。',
			ticketOpen: '已开启',
			ticketAnswered: '已回复',
			ticketResolved: '已解决',
			ticketCanceled: '已取消',
			ticketArchived: '已存档记录',
			ticketInfo: '需要更多信息',
			ticketAll: '查看所有表单'
		};

		Msg.cms = {
			requestError: '无法完成您的请求。',
			ignoreNot: '无法屏蔽该用户',
			ignoreAlready: '已屏蔽该用户',
			stickyRequested: '已要求置顶',
			stickyHasBeenRequested: '您已经为该主题发送过置顶请求。',
			postAdded: '已添加帖子至追踪器',
			postRemoved: '已将帖子从追踪器移除',
			userAdded: '已添加用户至追踪器',
			userRemoved: '已将用户从追踪器移除',
			validationError: '有需要填写栏位未完成',
			characterExceed: '发帖内容超过XXXXXX字。',
			searchFor: "搜索",
			searchTags: "已标记的文章：",
			characterAjaxError: "您可能已登出。请刷新页面并重试。",
			ilvl: "物品等级{0}",
			shortQuery: "搜索请求必须至少有2个字。",
			editSuccess: "操作成功，是否重新加载？",
			postDelete: "您确定要删除这篇留言吗？",
			throttleError: "您必须等待片刻才能再留言。"
		};

		Msg.bml= {
			bold: '粗体',
			italics: '斜体',
			underline: '下划线',
			list: '无序列表',
			listItem: '列表物品',
			quote: '引用',
			quoteBy: '由{0}引用',
			unformat: '移除格式',
			cleanup: '修正换行符',
			code: '代码段',
			item: '《魔兽世界》物品',
			itemPrompt: '物品ID：',
			url: 'URL',
			urlPrompt: 'URL地址：'
		};

		Msg.ui= {
			submit: '提交',
			cancel: '取消',
			reset: '重置',
			viewInGallery: '在画集中显示',
			loading: '正在加载',
			unexpectedError: '发生错误',
			fansiteFind: '正在寻找……',
			fansiteFindType: '正在寻找{0}……',
			fansiteNone: '尚无玩家网站。',
			flashErrorHeader: '必须安装Adobe Flash Player才可以浏览该内容。',
			flashErrorText: '下载Adobe Flash Player',
			flashErrorUrl: 'http://get.adobe.com/flashplayer/',
			save: '保存'
		};

		Msg.grammar= {
			colon: '{0}：',
			first: '第一',
			last: '最后',
			ellipsis: '……'
		};

		Msg.fansite= {
			achievement: '成就',
			character: '角色',
			faction: '阵营',
			'class': '职业',
			object: '物件',
			talentcalc: '天赋',
			skill: '专业',
			quest: '任务',
			spell: '法术',
			event: '事件',
			title: '头衔',
			arena: '竞技场队伍',
			guild: '公会',
			zone: '区域',
			item: '物品',
			race: '种族',
			npc: 'NPC',
			pet: '宠物'
		};
		Msg.search= {
			noResults: '没有找到任何匹配结果。',
			kb: '技术支持',
			post: '论坛',
			article: '文章',
			static: '内容',
			wowcharacter: '角色',
			wowitem: '物品',
			wowguild: '公会',
			wowarenateam: '竞技场战队',
			url: '推荐链接',
			friend: '好友',
			product: 'Marketplace产品',
			other: '其它'
		};
		//]]>
	</script>

		<?php echo $_smarty_tpl->getSubTemplate ("common_service.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

		<?php echo $_smarty_tpl->getSubTemplate ("common_header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
	
		<?php echo $_smarty_tpl->getSubTemplate ("block_content_auction.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
		
		<?php echo $_smarty_tpl->getSubTemplate ("common_footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

		</div>
	<div class="ui-tooltip" style="left: 147px; top: 2400px; display: none;">
			<div class="tooltip-content">正常</div>
	</div>
	<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['baseSet']->value['path_js'];?>
\menu.js?v=58" /></script>
	<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['baseSet']->value['path_js'];?>
\wow.js?v=37" /></script>
	<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['baseSet']->value['path_js'];?>
\search-pane.js?v=58" /></script>
	<script type="text/javascript">
		//<![CDATA[

		$(function() {
		//Menu.initialize('/data/menu.json');
		Search.initialize('/wow/zh/search/ta');
		});
		//]]>
	</script>

	<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['baseSet']->value['path_js'];?>
\dataset.js?v=58" /></script>	
	<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['baseSet']->value['path_js'];?>
\realm-status.js?v=37" /></script>
<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['baseSet']->value['path_js'];?>
\profile.js?v=37"></script>
<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['baseSet']->value['path_js'];?>
\auction.js?v=37"></script>
<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['baseSet']->value['path_js'];?>
\browse.js?v=37"></script>
<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['baseSet']->value['path_js'];?>
\collectible-popup.js?v=37"></script>
<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['baseSet']->value['path_js'];?>
\model-rotator.js?v=58"></script>
	<script type="text/javascript" >
		//<![CDATA[
		(function() {
			var ga = document.createElement('script');
			var src = "https://ssl.google-analytics.com/ga.js";
			if ('http:' == document.location.protocol) {
				src = "http://www.google-analytics.com/ga.js";
			}
			ga.type = 'text/javascript';
			ga.setAttribute('async', 'true');
			ga.src = src;
			var s = document.getElementsByTagName('script');
			s = s[s.length-1];
			s.parentNode.insertBefore(ga, s.nextSibling);
		})();
		//]]>
	</script>
	<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['baseSet']->value['path_js'];?>
\ga.js" /></script>
	<!--<script type="text/javascript" async="true" src="http://www.google-analytics.com/ga.js"></script>-->
	<div id="menu-container"></div>
	<div class="ui-typeahead" style="display: none;">正在加载</div>
	<div class="ui-tooltip" style="display: none;">
			<div class="tooltip-content"></div>
	</div>
</body>
</html><?php }} ?>
