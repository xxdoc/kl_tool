<?php /* Smarty version Smarty-3.1.16, created on 2014-03-03 18:13:58
         compiled from ".\html\web_status.tpl" */ ?>
<?php /*%%SmartyHeaderCode:9192531455e6f15476-81566363%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '248c550ddb2055558427bdb9f9901375777d0bef' => 
    array (
      0 => '.\\html\\web_status.tpl',
      1 => 1393700911,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '9192531455e6f15476-81566363',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'baseSet' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_531455e70a4023_62800861',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_531455e70a4023_62800861')) {function content_531455e70a4023_62800861($_smarty_tpl) {?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="zh-cn" class="zh-cn chrome chrome17">
<head xmlns:og="http://ogp.me/ns#" xmlns:fb="http://ogp.me/ns/fb#">
	<meta http-equiv="imagetoolbar" content="false" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title>服务器状态 - 游戏指南 - 魔兽世界</title>
	<link rel="shortcut icon" href="favicon.ico?v=58-37" />
	<link rel="stylesheet" type="text/css" media="all"
		href="<?php echo $_smarty_tpl->tpl_vars['baseSet']->value['path_css'];?>
common-game-site.css?v=58-37" />
	<link rel="stylesheet" type="text/css" media="all"
		href="<?php echo $_smarty_tpl->tpl_vars['baseSet']->value['path_css'];?>
wow.css?v=37" />
	<link rel="stylesheet" type="text/css" media="all"
		href="<?php echo $_smarty_tpl->tpl_vars['baseSet']->value['path_css'];?>
lightbox.css?v=37" />
	<link rel="stylesheet" type="text/css" media="all"
		href="<?php echo $_smarty_tpl->tpl_vars['baseSet']->value['path_css'];?>
realmstatus.css?v=37" />
	<!--[if IE]>
		<link rel="stylesheet" type="text/css" media="all" href="<?php echo $_smarty_tpl->tpl_vars['baseSet']->value['path_css'];?>
wow-ie.css?v=37" />
	<![endif]-->
	<!--[if IE 6]>
		<link rel="stylesheet" type="text/css" media="all" href="<?php echo $_smarty_tpl->tpl_vars['baseSet']->value['path_css'];?>
wow-ie6.css?v=37" />
	<![endif]-->
	<!--[if IE 7]>
		<link rel="stylesheet" type="text/css" media="all" href="<?php echo $_smarty_tpl->tpl_vars['baseSet']->value['path_css'];?>
wow-ie7.css?v=37" />
	<![endif]-->
	<link rel="stylesheet" type="text/css" media="all"
		href="<?php echo $_smarty_tpl->tpl_vars['baseSet']->value['path_css'];?>
zh-cn.css?v=37" />
	<link rel="stylesheet" type="text/css" media="all"
		href="<?php echo $_smarty_tpl->tpl_vars['baseSet']->value['path_css'];?>
ratings.css?v=58-37" />
</head>
<body class="zh-cn">
	<div id="wrapper">
		<?php echo $_smarty_tpl->getSubTemplate ("common_service.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

		<?php echo $_smarty_tpl->getSubTemplate ("common_header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
	
		<?php echo $_smarty_tpl->getSubTemplate ("block_content_status.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
		
		<?php echo $_smarty_tpl->getSubTemplate ("common_footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

	</div>
	<div class="ui-tooltip"
			style="left: 147px; top: 2400px; display: none;">
			<div class="tooltip-content">正常</div>
		</div>
	<div id="menu-container"></div>
	<div class="ui-typeahead" style="display: none;">正在加载</div>
	<div class="ui-tooltip" style="display: none;">
			<div class="tooltip-content"></div>
		</div>
</body>
</html><?php }} ?>
