<?php
require("smarty/smarty/libs/Smarty.class.php");

class SmartyProject extends Smarty {

	function __construct() {
		parent::__construct();
				
		$this->left_delimiter ='<!-{';
        $this->right_delimiter='}->'; 
		$this->template_dir = "./html/";
		$this->compile_dir = "./system/smarty/templates_c/";
		$this->config_dir = "./system/smarty/configs/";
		$this->cache_dir = "./system/smarty/cache/";
	}
	
} 


?>