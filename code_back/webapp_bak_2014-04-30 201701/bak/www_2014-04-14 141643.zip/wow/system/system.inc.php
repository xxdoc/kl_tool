<?php
require("system.smarty.inc.php");
require("system.class.inc.php");
//数据库连接类实例化

$_BASE_SET_SQL = array(
		 'sql_type'=>'mysql'
		,'sql_host' => 'localhost'
		,'sql_user' => 'root'
		,'sql_password' => 'root'
		,'sql_ah_db' => 'wow_ah_db'				//database for fwq_status , fwq_info , ah
		,'sql_info' => 'aa_fwq_info'
		,'sql_status' => 'aa_fwq_status'
		,'sql_ah_item' => 'aaa_ah_item'
		,'sql_item_db' => 'wow_item_db'			//database for guild , player
		,'sql_guild' => 'aaa_guild_list'
		,'sql_debug' => false
		,'sql_charset' => 'utf8'
		,'path_js' => '.\\js'
		,'path_css' => '.\\css'
		,'path_img' => '.\\img'
		,'path_data' => '.\\data'
		);

?>