<?php
require("system/system.inc.php");

$page_obj = new page_mysql();
$page_obj->indexAction();
?>


