<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php
echo "<head>\n";
echo "<meta http-equiv='Content-Type' content='text/html; charset=utf8' />\n";
echo "<title>123</title>\n";
echo "</head>\n";
echo "<pre>\n";

$yac = new Yac();

$key = "foo";
$value = "dummy";

var_dump($yac->set($key, $value));
var_dump($yac->get($key));

$value = NULL;
var_dump($yac->set($key, $value));
var_dump($yac->get($key));

$value = TRUE;
var_dump($yac->set($key, $value));
var_dump($yac->get($key));

$value = FALSE;
var_dump($yac->set($key, $value));
var_dump($yac->get($key));

$value = range(1, 5);
var_dump($yac->set($key, $value));
var_dump($yac->get($key));

$value = 9234324;
var_dump($yac->set($key, $value));
var_dump($yac->get($key));

$value = 9234324.123456;
var_dump($yac->set($key, $value));
var_dump($yac->get($key));

$value = new StdClass();;
var_dump($yac->set($key, $value));
var_dump($yac->get($key));

$value = fopen("php://input", "r");
var_dump($yac->set($key, $value));

$value = range(1, 5);
var_dump($yac->set($key, $value));
var_dump($yac->delete($key));
var_dump($yac->get($key));

/* 获取 microtime */
function get_microtime(){
	list($usec, $sec) = explode(' ', microtime(true));
	return $usec+$sec;
}
?>