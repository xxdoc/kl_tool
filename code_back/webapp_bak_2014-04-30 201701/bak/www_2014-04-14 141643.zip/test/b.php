<?php include_once 'a.php'; ?>
<?php function fb() { fa(); echo "in Function B/n"; } ?>