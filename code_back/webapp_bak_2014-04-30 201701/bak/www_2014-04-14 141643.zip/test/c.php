<?php include 'a.php'; ?>
<?php include 'b.php'; ?>
<?php fa(); fb(); ?>