<?php 
echo confirm_linvo_compiled(121);
echo "<p>".hello("1213313");

exit(0);

echo "<p>".linvo_md5_string("asaaewaeawe3213123weaweawaewe");
//echo "<p>".linvo_md5_file("1213313");
echo "<p>".linvo_byte2hex("1234567890");
echo "<p>".linvo_byte2hex("11111111111111111111111111111111111111111111");
echo "<p>".linvo_byte2hex("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
echo "<p>".linvo_byte2hex("1waeeeeeeeeeeeeeeeeeeeeeeweeeeeeeeeeeeeeeeeeee2");
echo "<p>".linvo_md5_string("abc");
echo "<p>".linvo_md5_string("r234234e");
echo "<p>".linvo_md5_string("d32423234234f");
echo "<p>".linvo_md5_string("fg234234234234234f");
echo "<p>".linvo_md5_string("124424312");

echo "<p>".linvo_md5_string_key("142344442341dfhdhdhfggggggggdffd23");
echo "<p>".linvo_md5_string_key("fg234234234234234f");
echo "<p>".linvo_md5_string_key("124424312");
echo "<p>".linvo_md5_string_key("fg234234234234234f");
echo "<p>".linvo_md5_string_key("124424312");

echo "<p>".linvo_des_encode_string("fg234234234234234f");
echo "<p>".linvo_des_decode_string("124424312");

echo "<p>".linvo_md5_string("fg234234234234234f");
echo "<p>".linvo_md5_string("124424312");
echo "<p>".linvo_md5_string("fg234234234234234f");
echo "<p>".linvo_md5_string("124424312");


?>