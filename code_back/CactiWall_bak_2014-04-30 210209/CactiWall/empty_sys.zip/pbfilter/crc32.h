//header file for crc32.c


void    crc32_init();
int     crc32_encode( char *str,unsigned int len );
