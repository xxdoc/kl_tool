import Vue from "vue";

import {
  router
} from "@/router/index";

import {
  appRouter
} from "@/router/router";

import store from "@/store";
import App from "@/app.vue";

import util from "@/libs/util";
import * as types from "@/types";

Vue.config.silent = !dms.debug;
Vue.config.devtools = dms.debug;
Vue.config.performance = dms.debug && false;

window.app = new Vue({
  el: "#app",
  router: router,
  store: store,
  render: h => h(App),
  data: {
    currentPageName: ""
  },
  mounted() {
    this.currentPageName = this.$route.name;
  },
  created() {
    dms.registerFuncGroup('_api_ajax_failure_', 'check_auth', (res) => {
      if (res.code == 531) {
        this._modal('error', '登录失效', '登录状态已经失效，请重新登录！', '确认', 2200, () => {
          this.$store.dispatch(types.LOGOUT);
        });
        return false;
      }
    });
  }
});