import util from "@/libs/util";
import * as _fragments from "@/fragments";
import * as _validates from "@/validates";
import Vue from 'vue'

export const fragments = _fragments;

export const validates = _validates;

/*************************************************************/
/*************************  常量相关  *************************/
/*************************************************************/

// state
export const app = "app";

// getters
export const D = "D";
export const isMobile = "isMobile";
export const user = "user";
export const _size = "_size";

// actions
export const INIT_APP = "INIT_APP";

/*************************************************************/
/**********  页面布局变动 回调函数 用于计算区域大小  ************/
/*************************************************************/

export const onResize = state => {
  onSinglePageResize(state);
  state.D.clientWidth = document.documentElement.clientWidth;
  state.D.clientHeight = document.documentElement.clientHeight;
  // console.log('onResize',  state.D.clientWidth, state.D.clientHeight)
};
