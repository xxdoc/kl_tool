export default {
    'clerk/home.vue': () => import('@/views/home/home.vue'),
}