
export const pageInfoPage = `
fragment pageInfoPage on PageInfo {
  total
  hasNextPage
  hasPreviousPage
  page
  num
}
`;

export const pageInfoAll = `
fragment pageInfoAll on PageInfo {
  ...pageInfoPage
  sortOption {
    field
    direction
  }
  allowSortField
}
${pageInfoPage}
`;

export const siteMgrUserBaseInfo = `
fragment siteMgrUserBaseInfo on SiteMgrUser {
    mgr_id
    mgr_slug
    name
    title
    avator
    email
    cellphone
    state
}
`;

export const siteMgrUserExtInfo = `
fragment siteMgrUserExtInfo on SiteMgrUser {
    login_ip
    login_location
    login_count
    login_time
    last_msg
    created_at
    updated_at
}
`;

export const siteMgrUserShow = `
fragment siteMgrUserShow on SiteMgrUser {
    ...siteMgrUserBaseInfo
    ...siteMgrUserExtInfo
}
${siteMgrUserBaseInfo}
${siteMgrUserExtInfo}
`;

export const adminBaseInfo = `
fragment adminBaseInfo on AdminUser {
  admin_id
  admin_type
  admin_slug
  admin_note
  business_id
  business_belong
  account_credit
  account_balance
  name
  title
  avator
  company
  industry
  cellphone
  email
  state
  register_from
}
`;

export const adminNumInfo = `
fragment adminNumInfo on AdminUser {
  limit_total
  room_num
  sub_num
  player_num
  stream_num
  agent_num
  parent_num
  viewer_now
  viewer_max
  viewer_max_at
}
`;

export const adminLimitInfo = `
fragment adminLimitInfo on AdminUser {
  vlimit_per_parent
  vlimit_per_room
  vlimit_all_room
  vlimit_online_num
  nlimit_count_parent
  nlimit_count_room
  nlimit_count_sub
  nlimit_count_player
  nlimit_count_stream
}
`;

export const adminLoginInfo = `
fragment adminLoginInfo on AdminUser {
  login_ip
  login_time
  login_count
  login_location
}
`;

export const adminExtInfo = `
fragment adminExtInfo on AdminUser {
  countly_duration_rate
  mcs_vhost
  cname_host
  cname_host2
  cname_cdn
  vod_cdn_map
  admin_config
  last_msg
  expiration_date
  updated_at
  created_at
  pasw_time
}
`;

export const adminShow = `
fragment adminShow on AdminUser {
  ...adminBaseInfo
  ...adminNumInfo
  ...adminLimitInfo
  ...adminLoginInfo
  ...adminExtInfo
  agent {
    ...adminBaseInfo
  }
}
${adminBaseInfo}
${adminNumInfo}
${adminLimitInfo}
${adminLoginInfo}
${adminExtInfo}
`;

export const adminMenuAclShow = `
fragment adminMenuAclShow on AdminUser {
  menuAcl
  ...adminBaseInfo
  ...adminNumInfo
  ...adminLimitInfo
  ...adminLoginInfo
  ...adminExtInfo
  agent {
    ...adminBaseInfo
  }
}
${adminBaseInfo}
${adminNumInfo}
${adminLimitInfo}
${adminLoginInfo}
${adminExtInfo}
`;

export const subAdminShow = `
fragment subAdminShow on AdminUser {
  ...adminBaseInfo
  ...adminNumInfo
  ...adminLimitInfo
  ...adminLoginInfo
  ...adminExtInfo
  agent {
    ...adminBaseInfo
  },
  parent {
    ...adminBaseInfo
  }
}
${adminBaseInfo}
${adminNumInfo}
${adminLimitInfo}
${adminLoginInfo}
${adminExtInfo}
`;

export const agentAdminShow = `
fragment agentAdminShow on AdminUser {
  ...adminBaseInfo
  ...adminNumInfo
  ...adminLimitInfo
  ...adminLoginInfo
  ...adminExtInfo
}
${adminBaseInfo}
${adminNumInfo}
${adminLimitInfo}
${adminLoginInfo}
${adminExtInfo}
`;

export const superAdminShow = `
fragment superAdminShow on AdminUser {
  ...adminBaseInfo
  ...adminLoginInfo
  ...adminExtInfo
}
${adminBaseInfo}
${adminLoginInfo}
${adminExtInfo}
`;

export const adminAclShow = `
fragment adminAclShow on AdminUser {
  menuAcl
  ...adminBaseInfo
  ...adminNumInfo
  ...adminLimitInfo
  ...adminLoginInfo
  ...adminExtInfo
  agent {
    ...adminBaseInfo
  }
}
${adminBaseInfo}
${adminNumInfo}
${adminLimitInfo}
${adminLoginInfo}
${adminExtInfo}
`;

export const subAdminAclShow = `
fragment subAdminAclShow on AdminUser {
   menuAcl
  ...adminBaseInfo
  ...adminNumInfo
  ...adminLimitInfo
  ...adminLoginInfo
  ...adminExtInfo
  agent {
    ...adminBaseInfo
  },
  parent {
    ...adminBaseInfo
  }
}
${adminBaseInfo}
${adminNumInfo}
${adminLimitInfo}
${adminLoginInfo}
${adminExtInfo}
`;

export const agentAdminAclShow = `
fragment agentAdminAclShow on AdminUser {
   menuAcl
  ...adminBaseInfo
  ...adminNumInfo
  ...adminLimitInfo
  ...adminLoginInfo
  ...adminExtInfo
}
${adminBaseInfo}
${adminNumInfo}
${adminLimitInfo}
${adminLoginInfo}
${adminExtInfo}
`;

export const adminInfo = `
fragment adminInfo on AdminUser {
  ...adminBaseInfo
  ...adminNumInfo
  ...adminLimitInfo
  ...adminLoginInfo
  ...adminExtInfo
}
${adminBaseInfo}
${adminNumInfo}
${adminLimitInfo}
${adminLoginInfo}
${adminExtInfo}
`;

export const streamBaseInfo = `
fragment streamBaseInfo on StreamBase {
    live_state
    admin_id
    stream_type
    stream_name
    stream_id
    stream_token
    state
    mcs_account
    mcs_password
    mcs_stream
    mcs_app
    mcs_vhost
}
`;

export const roomBaseInfo = `
fragment roomBaseInfo on LiveRoom {
    room_id
    room_token
    admin_id
    room_title
    room_alias
    stream_id
    v_stream_id
    live_state
    state
    d_stream_id
}
`;

export const streamExInfo = `
fragment streamExInfo on StreamBase {
    last_msg
    created_at
    updated_at
}
`;

export const streamUnionInfo = `
fragment streamUnionInfo on StreamUnion {
    ... on StreamMcs {
      __typename
      mcs_note
      mcs_id
      mcs_config
      is_forbid
    }
    ... on StreamPull {
      __typename
      pull_id
      rtmp_url
    }
    ... on StreamVod {
      __typename
      vod_id
      m3u8_url
      mp4_url
      flv_url
      vod_snaptshot
      v_duration
      v_ossbucket
      v_starttime
      v_createtime
      is_storage
      v_endtime
      v_stream_id
      v_room_id
      v_room{
        ...roomBaseInfo
      }
    }
    ... on StreamVss {
      __typename
      vod_id
      m3u8_url
      mp4_url
      flv_url
      mp4_size
      vod_snaptshot
      v_duration
      v_createtime
      v_starttime
      v_endtime
      v_stream_id
      v_room_id
      v_room{
        ...roomBaseInfo
      }
    }
    ... on StreamUpload {
      __typename
      file_name
      file_size
      md5_list
      vod_id
      m3u8_url
      mp4_url
      vod_snaptshot
      duration
      file_name
      created_at
      mp4_mts_state
      m3u8_mts_state
    }
    ... on StreamCaster {
        __typename
        caster_id
        caster_name
        channel_enable
        charge_type
        create_time
        norm_type
        caster_status
        last_room_id
        caster_config
        limit_caster_price
        limit_perid_caster_price
        charging_mode
    }
}
${roomBaseInfo}
`;

export const streamInfo = `
fragment streamInfo on StreamBase {
    ...streamBaseInfo
    stream{
        ...streamUnionInfo
    }
}
${streamBaseInfo}
${streamUnionInfo}
`;

export const streamShow = `
fragment streamShow on StreamBase {
    ...streamBaseInfo
    ...streamExInfo
    stream{
        ...streamUnionInfo
    }
    admin{
        ...adminBaseInfo
    }
    agent{
        ...adminBaseInfo
    }
}
${streamBaseInfo}
${streamExInfo}
${streamUnionInfo}
${adminBaseInfo}
`;

export const playerBaseInfo = `
fragment playerBaseInfo on PlayerBase {
    player_type
    state
    player_id
    player_name
    admin_id
}
`;

export const playerExInfo = `
fragment playerExInfo on PlayerBase {
    last_msg
    created_at
    updated_at
}
`;

export const playerUnionInfo = `
fragment playerUnionInfo on PlayerUnion {
            ... on PlayerAli {
              __typename
              width
              height
              autoplay
              isLive
              playsinline
              controlBarVisibility
              useH5Prism
              useFlashPrism
              cover
              skinLayout
            }
            ... on PlayerMps {
              __typename
              width
              height
              autostart
              controlbardisplay
              isclickplay
              isfullscreen
              stretching
              defvolume
              uin
              appId
              mobilefullscreen
              enablehtml5
              isloadcount
              israte
              wordsize
              wordcolor
              wordfont
              movespeed
              wordalpha
            }
            ... on PlayerAodian {
              __typename
              width
              height
              autostart
              controlbardisplay
              isclickplay
              isfullscreen
              stretching
              defvolume
              bufferlength
              maxbufferlength
              adveDeAddr
              adveWidth
              adveHeight
              adveReAddr
            }
}
`;

export const playerInfo = `
fragment playerInfo on PlayerBase {
    ...playerBaseInfo
    ...playerExInfo
}
${playerBaseInfo}
${playerExInfo}
`;

export const playerShow = `
fragment playerShow on PlayerBase {
    ...playerBaseInfo
    ...playerExInfo
    admin{
        ...adminBaseInfo
    }
    agent{
        ...adminBaseInfo
    }
}
${playerBaseInfo}
${playerExInfo}
${adminBaseInfo}
`;

export const roomExInfo = `
fragment roomExInfo on LiveRoom {
    viewlimit
    player_id
    viewer_count
    viewer_max
    viewer_max_at
    viewer_now
    video_bg
    last_msg
    updated_at
    created_at
}
`;

export const roomShow = `
fragment roomShow on LiveRoom {
    ...roomBaseInfo
    ...roomExInfo
    admin {
        ...adminBaseInfo
    }
    agent{
        ...adminBaseInfo
    }
    player{
        ...playerInfo
    }
    stream{
        ...streamInfo
    }
}
${roomBaseInfo}
${roomExInfo}
${adminBaseInfo}
${playerInfo}
${streamInfo}
`;

export const roomAutoVodShow = `
fragment roomAutoVodShow on LiveRoom {
    ...roomBaseInfo
    ...roomExInfo
    auto_vod {
      enable
      priority
      vodlist{
        stream_id
        range
        vod_stream {
            ...streamInfo
        }
      }
    }
    defaultStream {
        ...streamInfo
    }
    admin {
        ...adminBaseInfo
    }
    agent{
        ...adminBaseInfo
    }
}
${roomBaseInfo}
${roomExInfo}
${streamInfo}
${adminBaseInfo}
`;

export const roomInfo = `
fragment roomInfo on LiveRoom {
    ...roomBaseInfo
    ...roomExInfo
}
${roomBaseInfo}
${roomExInfo}
`;

export const roomViewRecordBaseInfo = `
fragment roomViewRecordBaseInfo on RoomViewRecord {
        id
        user_id
        admin_id
        room_id
        login_ip
        login_ip_addr
        record_state
        agent
        in_time
        out_time
        interval_time
        ref_host
        ref_url
}
`;

export const roomViewRecordExInfo = `
fragment roomViewRecordExInfo on RoomViewRecord {
        created_at
        updated_at 
}
`;

export const roomViewRecordShow = `
fragment roomViewRecordShow on RoomViewRecord {
        ...roomViewRecordBaseInfo
        ...roomViewRecordExInfo
        admin {
            ...adminBaseInfo
            agent{
                ...adminBaseInfo
            }
        }
        room {
            ...roomBaseInfo
        }
}
${roomViewRecordBaseInfo}
${roomViewRecordExInfo}
${adminBaseInfo}
${roomBaseInfo}
`;

export const roomViewRecordInfo = `
fragment roomViewRecordInfo on RoomViewRecord {
        ...roomViewRecordBaseInfo
        ...roomViewRecordExInfo
}
${roomViewRecordBaseInfo}
${roomViewRecordExInfo}
`;

export const dailyViewCountBaseInfo = `
fragment dailyViewCountBaseInfo on DailyViewCount {
        id
        admin_id
        room_id
        view_count
        per_day
        num_max
        num_max_time
        dms_num_max
        dms_num_max_time
        total_ip
        total_view_record
        total_unique_user
        total_interval_time
        created_at
        updated_at
}
`;

export const dailyViewCountFlowInfo = `
fragment dailyViewCountFlowInfo on DailyViewCount {
        ...dailyViewCountBaseInfo
        flow_up_total
        hw_flow_up_total
        flow_down_total
        hw_flow_down_total
        flow_up_total_ok
        hw_flow_up_total_ok
        flow_down_total_ok
        hw_flow_down_total_ok       
        flow_pre_num
        
        vss_up_total
        vss_down_total
        vss_up_total_ok
        vss_down_total_ok
        tmp_vss_up_total
        tmp_vss_down_total
        tmp_vss_up_total_ok
        tmp_vss_down_total_ok
        
        cloud_space_total_size
}
${dailyViewCountBaseInfo}
`;

export const dailyViewCountShow = `
fragment dailyViewCountShow on DailyViewCount {
        ...dailyViewCountBaseInfo
        admin {
            ...adminBaseInfo
            agent{
                ...adminBaseInfo
            }
        }
        room {
            ...roomBaseInfo
        }
}
${dailyViewCountBaseInfo}
${adminBaseInfo}
${roomBaseInfo}
`;

export const dailyViewCountFlowShow = `
fragment dailyViewCountFlowShow on DailyViewCount {
        ...dailyViewCountFlowInfo
        admin {
            ...adminBaseInfo
            agent{
                ...adminBaseInfo
            }
        }
        room {
            ...roomBaseInfo
        }
}
${dailyViewCountFlowInfo}
${adminBaseInfo}
${roomBaseInfo}
`;

export const dailyRoomRunningBaseInfo = `
fragment dailyRoomRunningBaseInfo on DailyRoomRunning {
        id
        admin_id
        room_id
        num_max
        num_max_time
        hw_num_max
        hw_num_max_time
        package_num
        over_price
        per_day
        created_at
        updated_at
}
`;

export const dailyRoomRunningFlowInfo = `
fragment dailyRoomRunningFlowInfo on DailyRoomRunning {
        ...dailyRoomRunningBaseInfo
        flow_up_total
        hw_flow_up_total
        flow_down_total
        hw_flow_down_total
        flow_up_total_ok
        hw_flow_up_total_ok
        flow_down_total_ok
        hw_flow_down_total_ok
        vss_up_total
        vss_down_total
        vss_up_total_ok
        vss_down_total_ok
        tmp_vss_up_total
        tmp_vss_down_total
        tmp_vss_up_total_ok
        tmp_vss_down_total_ok
        flow_pre_num
        package_num_price
        
        cloud_space_total_size
}
${dailyRoomRunningBaseInfo}
`;

export const dailyRoomRunningShow = `
fragment dailyRoomRunningShow on DailyRoomRunning {
        ...dailyRoomRunningBaseInfo
        admin{
          ...adminBaseInfo
        }
        room{
          ...roomBaseInfo
        }
}
${dailyRoomRunningBaseInfo}
${adminBaseInfo}
${roomBaseInfo}
`;

export const dailyRoomRunningFlowShow = `
fragment dailyRoomRunningFlowShow on DailyRoomRunning {
        ...dailyRoomRunningFlowInfo
        admin{
          ...adminBaseInfo
        }
        room{
          ...roomBaseInfo
        }
}
${dailyRoomRunningFlowInfo}
${adminBaseInfo}
${roomBaseInfo}
`;

export const roomRunningShow = `
fragment roomRunningShow on RoomRunning {
    id
    live_state
    admin_id
    agent_id
    room_id
    num
    timer_count
    timer_type
    ref_host
    admin{
        ...adminBaseInfo
    }
    agent{
        ...adminBaseInfo
    }
    room{
        ...roomBaseInfo
    }
}
${adminBaseInfo}
${roomBaseInfo}
`;

export const productBaseInfo = `
fragment productBaseInfo on XdyProduct {
    state
    product_id
    product_title
    product_price
    admin_id
    product_num
    product_type
    product_note
    sell_count
    limit_type
    limit_value
    expired_days
}
`;

export const noticeAclShow = `
fragment noticeAclShow on AdminUser {
      ...adminBaseInfo
      noticeAcl {
        notifyTime
        intervalOver
        intervalExpired
        intervalArrears
        enableOver
        enableExpired
        enableArrears
      }
}
${adminBaseInfo}
`;

export const productShow = `
fragment productShow on XdyProduct {
    ...productBaseInfo
    applyAdmin{
        ...adminBaseInfo
    }
    last_msg
    created_at
    updated_at
}
${productBaseInfo}
${adminBaseInfo}
`;

export const orderBaseInfo = `
fragment orderBaseInfo on XdyOrder {
    state
    order_id
    admin_id
    operator_id
    account_balance_after
    account_balance_before
    order_money
    order_note
    order_type
    product_id
    product_type
    product_value
    product_config
    admin_email
    admin_mobile
    m_state
    error_msg
}
`;

export const orderShow = `
fragment orderShow on XdyOrder {
    ...orderBaseInfo
    admin{
        ...adminBaseInfo
    }
    opAdmin{
        ...adminBaseInfo
    }
    product{
        ...productBaseInfo
    }
    last_msg
    created_at
    updated_at
}
${orderBaseInfo}
${adminBaseInfo}
${productBaseInfo}
`;

export const xdyAdminProductShow = `
fragment xdyAdminProductShow on XdyAdminProduct {
    id
    admin_id
    state
    product_id
    order_id
    product_type
    product_value
    product_config
    product_result
    expired_days
    start_time
    last_msg
    created_at
    updated_at
    admin{
        ...adminBaseInfo
    }
    order{
        ...orderBaseInfo
    }
    product{
        ...productBaseInfo
    }
}
${adminBaseInfo}
${orderBaseInfo}
${productBaseInfo}
`;

export const playerAclInfo = `
fragment playerAclInfo on PlayerAclInfo {
    enable
    empty_ref
    type
    hosts
}
`;

export const bufferAclInfo = `
fragment bufferAclInfo on BufferAclInfo {
    try_ios_autoplay
    try_android_autoplay
    try_vod_loop
    lss_player_bufferlength
    lss_player_maxbufferlength
    lss_player_isloadcount
    lss_player_scaling
    lss_player_m_fullscreen
    js_play_resize
}
`;

export const agentPlayerAclShow = `
fragment agentPlayerAclShow on AdminUser {
  ...adminBaseInfo
  playerAcl{
    ...playerAclInfo
  }
}
${adminBaseInfo}
${playerAclInfo}
`;

export const parentPlayerAclShow = `
fragment parentPlayerAclShow on AdminUser {
  ...adminBaseInfo
  agent{
    ...adminBaseInfo
  }
  playerAcl{
    ...playerAclInfo
  }
}
${adminBaseInfo}
${playerAclInfo}
`;

export const agentBufferAclShow = `
fragment agentBufferAclShow on AdminUser {
  ...adminBaseInfo
  bufferAcl{
    ...bufferAclInfo
  }
}
${adminBaseInfo}
${bufferAclInfo}
`;

export const parentBufferAclShow = `
fragment parentBufferAclShow on AdminUser {
  ...adminBaseInfo
  agent{
    ...adminBaseInfo
  }
  bufferAcl{
    ...bufferAclInfo
  }
}
${adminBaseInfo}
${bufferAclInfo}
`;

export const qosAclInfo = `
fragment qosAclInfo on QosAclInfo {
    track_sessions
    track_pageview
    track_clicks
    track_links
    track_forms
    track_errors
    qos_duration
    pc_loading
    mobile_loading
    pc_dms_loading
    mobile_dms_loading
}
`;

export const agentQosAclShow = `
fragment agentQosAclShow on AdminUser {
  ...adminBaseInfo
  qosAcl{
    ...qosAclInfo
  }
}
${adminBaseInfo}
${qosAclInfo}
`;

export const parentQosAclShow = `
fragment parentQosAclShow on AdminUser {
  ...adminBaseInfo
  agent{
    ...adminBaseInfo
  }
  qosAcl{
    ...qosAclInfo
  }
}
${adminBaseInfo}
${qosAclInfo}
`;

export const mcsLogShow = `
fragment mcsLogShow on CountlyPushMcsLog {
    admin{
      ...adminBaseInfo
      agent{
        ...adminBaseInfo
      }
    }
    stream{
        ...streamInfo
    }
    id
    key_str
    count_num
    segmentation
    remote_ip
    app_ver
    log_id
    countly_id
    mcs_id
    stream_id
    location_str
    device_str
    device_id
    segmentation
    ts
    req_ts
    time_stamp
    count_num
    sum_num
}
${adminBaseInfo}
${streamInfo}
`;
