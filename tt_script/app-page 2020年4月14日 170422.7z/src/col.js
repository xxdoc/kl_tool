import util from "@/libs/util";
import * as types from "@/types";

const NORMAL = app.D.types.StateEnum.NORMAL._v;

var baseEditAble = user.admin_type != "super" || user.admin_slug == "xdy_super";
var issuper = user.admin_type == "super";
/************  通用 字段 **************/

export const selection = {
  type: "selection",
  key: "selection",
  width: 50,
  align: "center",
  fixed: "left"
};

export const state = {
  title: "状态",
  key: "state",
  width: 70,
  align: "center",
  render(h, {
    row,
    column,
    index
  }) {
    return util.renderState(h, row.state || NORMAL);
  }
};

export const d_mcs_account = {
  title: "默认直播账号",
  key: "d_mcs_account",
  align: "center",
  width: 80,
  render(h, {
    row,
    column,
    index
  }) {
    return h("Span", row.defaultStream ? row.defaultStream.mcs_account : "");
  }
};

export const per_day = {
  title: "日期",
  width: 90,
  align: "center",
  key: "per_day",
  render(h, {
    row,
    column,
    index
  }) {
    var str = dms.date("Y-m-d", util.intday2time(row.per_day));
    return h(
      "Span", {
        style: {
          color: str == dms.date("Y-m-d") ? types.C_Success : types.C_Normal
        },
        attrs: {
          title: str == dms.date("Y-m-d") ?
            "今日数据实时统计中，更新时间：" + row.updated_at : ""
        }
      },
      str
    );
  }
};

export const login_ip = {
  title: "IP",
  width: 130,
  align: "center",
  key: "login_ip"
};

export const ref_host = {
  title: "域名",
  width: 160,
  align: "center",
  key: "ref_host"
};

export const admin_title = {
  title: "客户",
  key: "admin_title",
  tag: "title",
  width: 155,
  align: "center",
  render(h, {
    row,
    column,
    index
  }) {
    if (row.admin == undefined) {
      return '';
    }
    return util.renderState(
      h,
      row.admin ? row.admin.state || NORMAL : NORMAL,
      types.renderStrByTag("admin", row.admin)
    );
  }
};

export const admin_admin_note = {
  title: "客户备注",
  key: "admin_admin_note",
  width: 155,
  align: "center",
  render(h, {
    row,
    column,
    index
  }) {
    return h("Span", [row.admin ? row.admin.admin_note : "-"]);
  }
};

export const agent_title = {
  title: "代理",
  key: "agent_title",
  tag: "title",
  width: 155,
  align: "center",
  render(h, {
    row,
    column,
    index
  }) {
    if (row.agent == undefined) {
      return '';
    }
    return util.renderState(
      h,
      row.agent ? row.agent.state || NORMAL : row.agent,
      types.renderStrByTag("admin", row.agent)
    );
  }
};

export const admin_agent_title = {
  title: "代理",
  key: "admin_agent_title",
  tag: "title",
  width: 155,
  align: "center",
  render(h, {
    row,
    column,
    index
  }) {
    return util.renderState(
      h,
      row.admin && row.admin.agent ? row.admin.agent.state || NORMAL : NORMAL,
      types.renderStrByTag("admin", row.admin ? row.admin.agent : {})
    );
  }
};

export const room_room_title = {
  title: "频道",
  width: 155,
  align: "center",
  key: "room_room_title",
  tag: "title",
  render(h, {
    row,
    column,
    index
  }) {
    return h("Span", [row.room ? types.renderStrByTag("room", row.room) : "-"]);
  }
};

export const created_at = {
  title: "创建时间",
  width: 155,
  align: "center",
  key: "created_at"
};

export const updated_at = {
  title: "更新时间",
  width: 155,
  align: "center",
  key: "updated_at"
};

export const created_at_updated_at = [created_at, updated_at];

/************  Admin 字段 **************/

export const admin_id = {
  title: "客户ID",
  key: "admin_id",
  tag: "id",
  width: 70,
  align: "center",
  fixed: "left"
};

export const title = {
  title: "名称",
  key: "title",
  tag: "title",
  width: 130,
  align: "center",
  editable: true,
  fixed: "left"
};

export const admin_note = {
  title: "备注",
  key: "admin_note",
  align: "center",
  width: 160,
  editable: baseEditAble,
  fixed: "left"
};

export const admin_id_title_admin_note = [admin_id, title, admin_note];

export const name = {
  title: "账号",
  key: "name",
  tag: "title",
  width: 130,
  align: "center",
  editable: true
};

export const acl_admin_id_title_name = [{
    title: "客户ID",
    key: "admin_id",
    tag: "id",
    width: 70,
    align: "center"
  },
  {
    title: "名称",
    key: "title",
    tag: "title",
    width: 130,
    align: "center"
  },
  {
    title: "账号",
    key: "name",
    width: 130,
    align: "center"
  }
];

export const vlimit_all_room = {
  title: "并发限制",
  key: "vlimit_all_room",
  width: 85,
  align: "center",
  editable: true
};

export const nlimit_count_room = {
  title: "频道限制",
  key: "nlimit_count_room",
  width: 85,
  align: "center",
  editable: true
};

export const nlimit_count_parent = {
  title: "客户限制",
  key: "nlimit_count_parent",
  width: 85,
  align: "center",
  editable: true
};

export const auto_vod_priority = {
  title: "优先直播",
  key: "auto_vod_priority",
  align: "center",
  width: 85,
  render(h, {
    row,
    column,
    index
  }) {
    return h("i-switch", {
      props: {
        size: "large",
        type: "primary",
        value: row.auto_vod.priority == "live"
      },
      on: {
        "on-change": (value) => {
          var copyVodlist = row.auto_vod.vodlist.map((value) => {
            return {
              stream_id: value.stream_id,
              range: value.range
            };
          });

          var value = {
            enable: row.auto_vod.enable,
            priority: value ? "live" : "vod",
            vodlist: copyVodlist
          }

          dms.ContentMgr.setContent({
              name: "roomcfg.auto_vod",
              value: value,
              filed: "content_config",
              admin_id: row.admin_id,
              room_id: row.room_id
            })
            .then(resp => {
              app._success(resp);
            })
            .catch(resp => {
              app._error(resp);
            })
            .finally(() => {

            });
        }
      }
    }, [
      h("span", {
        slot: "open"
      }, "直播"),
      h("span", {
        slot: "close"
      }, "点播")
    ])
  }
};

export const auto_vod_enable = {
  title: "是否开启",
  key: "auto_vod_enable",
  align: "center",
  width: 85,
  render(h, {
    row,
    column,
    index
  }) {
    return h("i-switch", {
      props: {
        size: "large",
        type: "primary",
        value: row.auto_vod.enable == 1
      },
      on: {
        "on-change": (value) => {
          var copyVodlist = row.auto_vod.vodlist.map((value) => {
            return {
              stream_id: value.stream_id,
              range: value.range
            };
          });
          var value = {
            enable: value ? 1 : 0,
            priority: row.auto_vod.priority,
            vodlist: copyVodlist
          }

          dms.ContentMgr.setContent({
              name: "roomcfg.auto_vod",
              value: value,
              filed: "content_config",
              admin_id: row.admin_id,
              room_id: row.room_id
            })
            .then(resp => {
              app._success(resp);
            })
            .catch(resp => {
              app._error(resp);
            })
            .finally(() => {

            });
        }
      }
    }, [
      h("span", {
        slot: "open"
      }, "ON"),
      h("span", {
        slot: "close"
      }, "OFF")
    ])
  }
};

export const vlimit_online_num = {
  title: "并发限制",
  key: "vlimit_online_num",
  width: 85,
  align: "center",
  editable: true
};

export const limit_total = {
  title: "并发套餐",
  key: "limit_total",
  width: 85,
  align: "center"
};

export const parent_num = {
  title: "客户数量",
  key: "parent_num",
  width: 85,
  align: "center"
};

export const room_num = {
  title: "频道数量",
  key: "room_num",
  width: 85,
  align: "center"
};

export const parent_title = {
  title: "所属客户",
  key: "parent_title",
  tag: "title",
  width: 155,
  align: "center",
  render(h, {
    row,
    column,
    index
  }) {
    return util.renderState(
      h,
      row.parent ? row.parent.state || NORMAL : NORMAL,
      types.renderStrByTag("admin", row.parent)
    );
  }
};

export const parent_title_agent_title = [parent_title, agent_title];

export const register_from = {
  title: "来源",
  width: 90,
  align: "center",
  key: "register_from"
};

export const viewer_now = {
  title: "当前并发",
  key: "viewer_now",
  width: 85,
  align: "center",
  render(h, {
    row,
    column,
    index
  }) {
    return util.renderRoomRunningBtn(
      h,
      row.viewer_now,
      (row.room_id ?
        types.renderStrByTag("room", row, "并发数据") :
        types.renderStrByTag("admin", row, "并发数据")) + " " + dms.date("Y-m-d"),
      row.room_id || 0,
      row.admin_id || 0
    );
  }
};

export const viewer_max = {
  title: "最高并发",
  key: "viewer_max",
  width: 85,
  align: "center",
  render(h, {
    row,
    column,
    index
  }) {
    return h(
      "Span", {
        attrs: {
          title: row.viewer_max_at
        }
      },
      row.viewer_max
    );
  }
};

export const viewer_now_viewer_max = [viewer_now, viewer_max];

export const admin_slug = {
  title: "SLUG",
  width: 110,
  key: "admin_slug",
  align: "center",
  editable: true
};

export const mcs_vhost = {
  title: "视频流vhost",
  key: "mcs_vhost",
  width: 180,
  align: "center",
  editable: true
};

export const countly_duration_rate = {
  title: "统计参数",
  key: "countly_duration_rate",
  width: 90,
  align: "center",
  editable: true
};

export const cname_host = {
  title: "后台CNAME",
  key: "cname_host",
  width: 130,
  align: "center",
  editable: true
};
export const cname_host2 = {
  title: "后台CNAME2",
  key: "cname_host2",
  width: 130,
  align: "center",
  editable: true
};

export const cname_cdn = {
  title: "CDN-CNAME",
  key: "cname_cdn",
  width: 130,
  align: "center",
  editable: true
};

export const vod_cdn_map = {
  title: "CDN-MAP",
  key: "vod_cdn_map",
  width: 130,
  align: "center",
  editable: true
}

export const expiration_date = {
  title: "有效期",
  key: "expiration_date",
  width: 200,
  align: "center",
  editable: true,
  spanLeft: "20",
  spanRight: "4",
  storeVal: (row, value) => {
    value = value || "0000-00-00 00:00:00";
    row[expiration_date] = value;
  },
  renderEdit: (h, {
    row,
    onChange
  }) => {
    return h("DatePicker", {
      props: {
        value: row.expiration_date == "0000-00-00 00:00:00" ?
          "" : row.expiration_date,
        type: "datetime",
        clearable: true,
        transfer: true,
        placeholder: "不设置表示永久有效"
      },
      style: {
        width: "160px"
      },
      on: {
        "on-change"(value) {
          value = value || "0000-00-00 00:00:00";
          onChange(value);
        },
        "on-clear"() {
          onChange("0000-00-00 00:00:00");
        }
      }
    });
  },
  renderStyle: ({
    row,
    column,
    index
  }) => {
    return {
      color: row.expiration_date == "0000-00-00 00:00:00" ||
        row.expiration_date > dms.date("Y-m-d H:i:s") ?
        types.C_Normal : types.C_Warning
    };
  }
};

export const email = {
  title: "邮箱",
  key: "email",
  width: 200,
  align: "center",
  editable: true
};

export const cellphone = {
  title: "手机",
  key: "cellphone",
  width: 160,
  align: "center",
  editable: true
};

export const company = {
  title: "公司",
  key: "company",
  width: 160,
  editable: true
};

export const industry = {
  title: "行业",
  key: "industry",
  width: 160,
  editable: true
};

export const email_cellphone_company_industry = [
  email,
  cellphone,
  company,
  industry
];

export const login_time = {
  title: "上次登录时间",
  width: 160,
  align: "center",
  key: "login_time"
};

export const login_location = {
  title: "地域",
  width: 160,
  key: "login_location"
};

export const login_time_login_ip_login_location = [
  login_time,
  login_ip,
  login_location
];

export const cfg_show_parent_num = {
  title: "客户后台显示频道并发",
  key: "cfg_show_parent_num",
  align: "center",
  width: 88,
  editable: true,
  renderVal: row => {
    var tmp = row.admin_config ? JSON.parse(row.admin_config) : {};
    var key = 'show_parent_num';
    return tmp[key] ? tmp[key] : '';
  }
};

export const cfg_site_ico = {
  title: "站点ICO",
  key: "cfg_site_ico",
  align: "center",
  width: 88,
  imgupload: true,
  config: {
    width: 70,
    height: 45,
    iconSize: 20
  },
  imgval: (column, row) => {
    let tmp = row.admin_config ? JSON.parse(row.admin_config) : {};
    let key = column.key.replace("cfg_", "");
    return tmp[key] ? [{
      url: tmp[key],
      name: tmp[key]
    }] : [];
  }
};

export const cfg_admin_logo = {
  title: "后台菜单logo",
  key: "cfg_admin_logo",
  align: "center",
  width: 180,
  imgupload: true,
  config: {
    width: 162,
    height: 45,
    iconSize: 20
  },
  imgval: (column, row) => {
    let tmp = row.admin_config ? JSON.parse(row.admin_config) : {};
    let key = column.key.replace("cfg_", "");
    return tmp[key] ? [{
      url: tmp[key],
      name: tmp[key]
    }] : [];
  }
};

export const avator = {
  title: "后台头像",
  key: "avator",
  align: "center",
  width: 68,
  imgupload: true,
  config: {
    width: 55,
    height: 55,
    iconSize: 14
  },
  imgval: (column, row) => {
    let tmp = row || {};
    let key = 'avator';
    return tmp[key] ? [{
      url: tmp[key],
      name: tmp[key]
    }] : [];
  }
};

export const cfg_admin_mlogo = {
  title: "后台菜单logo(小)",
  key: "cfg_admin_mlogo",
  align: "center",
  width: 88,
  imgupload: true,
  config: {
    width: 70,
    height: 45,
    iconSize: 20
  },
  imgval: (column, row) => {
    let tmp = row.admin_config ? JSON.parse(row.admin_config) : {};
    let key = column.key.replace("cfg_", "");
    return tmp[key] ? [{
      url: tmp[key],
      name: tmp[key]
    }] : [];
  }
};

export const cfg_login_logo = {
  title: "登陆页面logo",
  key: "cfg_login_logo",
  align: "center",
  width: 160,
  imgupload: true,
  config: {
    width: 142,
    height: 45,
    iconSize: 20
  },
  imgval: (column, row) => {
    let tmp = row.admin_config ? JSON.parse(row.admin_config) : {};
    let key = column.key.replace("cfg_", "");
    return tmp[key] ? [{
      url: tmp[key],
      name: tmp[key]
    }] : [];
  }
};

export const cfg_vod_logo = {
  title: "点播默认封面",
  key: "cfg_vod_logo",
  align: "center",
  width: 88,
  imgupload: true,
  config: {
    width: 70,
    height: 45,
    iconSize: 20
  },
  imgval: (column, row) => {
    let tmp = row.admin_config ? JSON.parse(row.admin_config) : {};
    let key = column.key.replace("cfg_", "");
    return tmp[key] ? [{
      url: tmp[key],
      name: tmp[key]
    }] : [];
  }
};

export const cfg_site_ico_logo_mlogo = [
  cfg_site_ico,
  cfg_admin_logo,
  cfg_admin_mlogo,
  cfg_login_logo,
  cfg_vod_logo
];

/*********** 频道 字段  *************/

export const room_title = {
  title: "频道名称",
  key: "room_title",
  tag: "title",
  width: 130,
  align: "center",
  editable: true,
  fixed: "left"
};

export const room_alias = {
  title: "频道别名",
  key: "room_alias",
  width: 80,
  align: "center",
  fixed: "left"
};

export const viewlimit = {
  title: "并发限制",
  key: "viewlimit",
  width: 85,
  align: "center",
  editable: true
};

export const video_bg = {
  title: "视频背景",
  key: "video_bg",
  width: 160,
  align: "center",
  imgupload: true
};

export const player_player_name = {
  title: "播放器",
  key: "player_player_name",
  width: 115,
  align: "center",
  render(h, {
    row,
    column,
    index
  }) {
    return row.player ?
      util.renderState(h, row.player.state, row.player.player_name) :
      h("span", "默认播放器");
  }
};

export const stream_mcs_account = {
  title: "直播账号",
  key: "stream_mcs_account",
  width: 120,
  align: "center",
  editable: true,
  storeVal(row, val) {
    row.stream.mcs_account = val;
  },
  renderVal(row) {
    return row.stream ? row.stream.mcs_account : "";
  }
};

export const stream_mcs_password = {
  title: "直播密码",
  key: "stream_mcs_password",
  width: 120,
  align: "center",
  editable: true,
  storeVal(row, val) {
    row.stream.mcs_password = val;
  },
  renderVal(row) {
    return row.stream ? row.stream.mcs_password : "";
  }
};

export const stream_mcs_stream = {
  title: "stream",
  key: "stream_mcs_stream",
  width: 190,
  align: "center",
  render(h, {
    row,
    column,
    index
  }) {
    if (row.stream && row.stream.stream_type == "STREAM_MCS") {
      var btns = [
        row.stream.mcs_stream,
        util.renderStreamHistoryBtn(
          h,
          "历史",
          types.renderStrByTag("room", row, " - 推流历史"),
          row.stream.stream_id, {
            color: "#5cadff",
            padding: "2px 2px"
          }
        )
      ];
      if (user.admin_type == "super") {
        btns.push(
          util.renderStreamInfoBtn(
            h,
            "信息",
            types.renderStrByTag("room", row, " - 推流信息"),
            row.stream.stream_id, {
              color: "#5cadff",
              padding: "2px 2px"
            }
          )
        );
        btns.push(
          util.renderRoomQosBtn(
            h,
            "流畅度",
            types.renderStrByTag("room", row, " - 播放流畅度"),
            row.room_id, {
              color: "#5cadff",
              padding: "2px 2px"
            }
          )
        );
      } else {
        btns.push(
          util.renderStreamFpsBtn(
            h,
            "信息",
            types.renderStrByTag("room", row, " - 推流信息"),
            row.stream.stream_id, {
              color: "#5cadff",
              padding: "2px 2px"
            }
          )
        );
      }
      return h("Span", btns);
    } else if (row.stream && row.stream.stream_type == "STREAM_VOD") {
      return h("Span", row.stream.stream_name);
    } else if (row.stream && row.stream.stream_type == "STREAM_UPLOAD") {
      return h("Span", row.stream.stream_name);
    } else if (row.stream && row.stream.stream_type == "STREAM_VSS") {
      return h("Span", row.stream.stream_name);
    }
    return h("Span", "-");
  }
};


export const mcs_vhost_show = {
  title: "vhost",
  key: "mcs_vhost_show",
  width: 125,
  align: "center",
  render(h, {
    row,
    column,
    index
  }) {
    if (row.stream_type == "STREAM_MCS") {
      var btns = [
        row.mcs_vhost
      ];
      var mcs_config_str = row.stream.mcs_config || {};
      var mcs_config = JSON.parse(mcs_config_str);
      if (user.admin_type == "super") {
        btns.push(
          util.renderTextModalBtn(
            h,
            "rtmp",
            types.renderStrByTag("stream", row, " - RTMP"),
            mcs_config.play_rtmp_url, {
              color: "#5cadff",
              padding: "2px 2px"
            }
          )
        );

        btns.push(
          util.renderTextModalBtn(
            h,
            "hls",
            types.renderStrByTag("stream", row, " - HLS"),
            mcs_config.play_hls_url, {
              color: "#5cadff",
              padding: "2px 2px"
            }
          )
        );
      }
      return h("Span", btns);
    }
    return h("Span", "-");
  }
}

export const stream_mcs_vhost = {
  title: "vhost",
  key: "stream_mcs_vhost",
  width: 125,
  align: "center",
  render(h, {
    row,
    column,
    index
  }) {
    if (row.stream && row.stream.stream_type == "STREAM_MCS") {
      var btns = [
        row.stream.mcs_vhost
      ];
      var mcs_config_str = row.stream.stream.mcs_config || {};
      var mcs_config = JSON.parse(mcs_config_str);
      if (user.admin_type == "super") {
        btns.push(
          util.renderTextModalBtn(
            h,
            "rtmp",
            types.renderStrByTag("room", row, " - RTMP"),
            mcs_config.play_rtmp_url, {
              color: "#5cadff",
              padding: "2px 2px"
            }
          )
        );

        btns.push(
          util.renderTextModalBtn(
            h,
            "hls",
            types.renderStrByTag("room", row, " - HLS"),
            mcs_config.play_hls_url, {
              color: "#5cadff",
              padding: "2px 2px"
            }
          )
        );
      }
      return h("Span", btns);
    }
    return h("Span", "-");
  }
}

export const room_id_live_state = {
  title: "频道ID",
  key: "room_id",
  tag: "id",
  width: 110,
  align: "left",
  fixed: "left",
  render(h, {
    row,
    column,
    index
  }) {
    return util.renderLiveState(h, row.live_state, row.room_id);
  }
};

/***********  runningCols 字段 ***********/

export const num = {
  title: "并发",
  width: 160,
  align: "center",
  key: "num"
};

export const timer_count = {
  title: "时间",
  width: 160,
  align: "center",
  key: "timer_count",
  render(h, {
    row,
    column,
    index
  }) {
    return h(
      "Span",
      dms.date("Y-m-d H:i", util.count2time(row.timer_count, row.timer_type))
    );
  }
};

/***********  mcsMgrCols 字段 ***********/
export const stream_id = {
  title: "直播账号ID",
  key: "stream_id",
  tag: "id",
  width: 132,
  align: "left",
  fixed: "left",
  render(h, {
    row,
    column,
    index
  }) {
    return util.renderLiveState(h, row.live_state, row.stream_id);
  }
};

export const stream_name = {
  title: "直播备注",
  key: "stream_name",
  tag: "title",
  width: 160,
  align: "center",
  fixed: "left",
  editable: true
};

export const mcs_account = {
  title: "直播账号",
  key: "mcs_account",
  width: 120,
  align: "center",
  editable: true,
  renderVal: row => {
    return row.mcs_account || "";
  },
  fixed: "left"
};

export const mcs_password = {
  title: "直播密码",
  key: "mcs_password",
  width: 120,
  align: "center",
  editable: true,
  renderVal: row => {
    return row.mcs_password || "";
  }
};

export const mcs_stream = {
  title: "stream",
  key: "mcs_stream",
  width: 180,
  align: "center",
  render(h, {
    row,
    column,
    index
  }) {
    var btns = [
      row.mcs_stream,
      util.renderStreamHistoryBtn(
        h,
        "历史",
        types.renderStrByTag("stream", row, " - 推流历史"),
        row.stream_id, {
          color: "#5cadff"
        }
      )
    ];

    if (user.admin_type == "super") {
      btns.push(
        util.renderStreamInfoBtn(
          h,
          "信息",
          types.renderStrByTag("stream", row, " - 推流信息"),
          row.stream_id, {
            color: "#5cadff"
          }
        )
      );
    } else {
      btns.push(
        util.renderStreamFpsBtn(
          h,
          "信息",
          types.renderStrByTag("stream", row, " - 推流信息"),
          row.stream_id, {
            color: "#5cadff"
          }
        )
      );
    }
    return row.mcs_stream ? h("Span", btns) : h("Span", "-");
  }
};

export const resolve_by_ip = {
  title: "节点IP",
  key: "resolve_by_ip",
  width: 80,
  align: "center",
  render(h, {
    row,
    column,
    index
  }) {
    var vm = column._vm ? column._vm() : null;
    var mcs_config = JSON.parse(row.stream.mcs_config);
    return h("i-switch", {
      props: {
        value: mcs_config.resolve_by_ip,
        "true-value": 1,
        "false-value": 0,
        size: "large"
      },
      on: {
        "on-change": (val) => {
          app.$store.commit(types.SPIN_SHOW, true);
          dms.StreamMgr.setMcsConfig({
            stream_id: row.stream_id,
            resolve_by_ip: val
          }).then(resp => {
            app._success(resp);
          }).catch(resp => {
            app._error(resp);
          }).finally(() => {
            app.$store.commit(types.SPIN_SHOW, false);
            vm && vm.tableOnAction(types.A_Reload);
          });
        }
      }
    }, [
      h("span", {
        slot: "open"
      }, "开启"),
      h("span", {
        slot: "close"
      }, "关闭"),
    ]);
  }
}

export const auto_copy_stream = {
  title: "同步拉流",
  key: "auto_copy_stream",
  width: 80,
  align: "center",
  render(h, {
    row,
    column,
    index
  }) {
    var vm = column._vm ? column._vm() : null;
    var mcs_config = JSON.parse(row.stream.mcs_config);
    return h("i-switch", {
      props: {
        value: mcs_config.auto_copy_stream,
        "true-value": 1,
        "false-value": 0,
        size: "large"
      },
      on: {
        "on-change": (val) => {
          app.$store.commit(types.SPIN_SHOW, true);
          dms.StreamMgr.setMcsConfig({
            stream_id: row.stream_id,
            auto_copy_stream: val
          }).then(resp => {
            app._success(resp);
          }).catch(resp => {
            app._error(resp);
          }).finally(() => {
            app.$store.commit(types.SPIN_SHOW, false);
            vm && vm.tableOnAction(types.A_Reload);
          });
        }
      }
    }, [
      h("span", {
        slot: "open"
      }, "开启"),
      h("span", {
        slot: "close"
      }, "关闭"),
    ]);
  }
}

export const cur_active = {
  title: "当前视频流",
  key: "cur_active",
  width: 80,
  align: "center",
  render(h, {
    row,
    column,
    index
  }) {
    var vm = column._vm ? column._vm() : null;
    var mcs_config = JSON.parse(row.stream.mcs_config);
    return h("i-switch", {
      props: {
        value: mcs_config.cur_active,
        "true-value": "copy",
        "false-value": "",
        size: "large"
      },
      on: {
        "on-change": (val) => {
          app.$store.commit(types.SPIN_SHOW, true);
          dms.StreamMgr.setMcsConfig({
            stream_id: row.stream_id,
            cur_active: val
          }).then(resp => {
            app._success(resp);
          }).catch(resp => {
            app._error(resp);
          }).finally(() => {
            app.$store.commit(types.SPIN_SHOW, false);
            vm && vm.tableOnAction(types.A_Reload);
          });
        }
      }
    }, [
      h("span", {
        slot: "open"
      }, "备份"),
      h("span", {
        slot: "close"
      }, "原始"),
    ]);
  }
}

export const mcs_config_show = [{
    title: "最大分辨率",
    key: "mcs_config.MaxOutResolution",
    width: 90,
    align: "center",
    render(h, {
      row,
      column,
      index
    }) {
      var vm = column._vm ? column._vm() : null;
      var mcs_config = JSON.parse(row.stream.mcs_config);
      return h("span", {}, mcs_config.MaxOutResolution);
    }
  }, {
    title: "视频质量",
    key: "mcs_config.VDFPS",
    width: 90,
    align: "center",
    render(h, {
      row,
      column,
      index
    }) {
      var vm = column._vm ? column._vm() : null;
      var mcs_config = JSON.parse(row.stream.mcs_config);
      return h("span", {}, mcs_config.VD_method == 'vbr' ? `${mcs_config.VDFPS}fps Qos:${mcs_config.VDBitRate}` : `${mcs_config.VDFPS}fps Bps:${mcs_config.VDBitRate}kb/s`);
    }
  }

]

export const is_forbid = {
  title: "禁播状态",
  key: "is_forbid",
  width: 115,
  align: "center",
  render(h, {
    row,
    column,
    index
  }) {
    return h(
      "Span", {
        style: {
          color: row.stream.is_forbid ? 'red' : ''
        }
      },
      row.stream.is_forbid == 1 ? '已禁播' : '未禁播'
    );
  }
};

/**************   figuerRecordCols 字段  ****************/

export const user_id = {
  title: "用户",
  width: 125,
  align: "center",
  key: "user_id",
  tag: "title",
  fixed: "left"
};

export const agent = {
  title: "设备",
  width: 90,
  align: "center",
  key: "agent",
  render(h, {
    row,
    column,
    index
  }) {
    return util.renderEnum(h, row.agent, types.RecordAgentList);
  }
};

export const in_time = {
  title: "进入时间",
  width: 160,
  align: "center",
  key: "in_time"
};

export const out_time = {
  title: "退出时间",
  width: 160,
  align: "center",
  key: "out_time"
};

export const interval_time = {
  title: "观看时长",
  width: 120,
  align: "center",
  key: "interval_time",
  render(h, {
    row,
    column,
    index
  }) {
    return util.renderIntervalTime(h, row.interval_time);
  }
};

export const in_time_out_time_interval_time = [
  in_time,
  out_time,
  interval_time
];

export const record_state = {
  title: "状态",
  width: 90,
  key: "record_state",
  align: "center",
  render(h, {
    row,
    column,
    index
  }) {
    return util.renderEnum(h, row.record_state, types.RecordStateEnum);
  }
};

export const ref_url = {
  title: "来源网址",
  width: 220,
  align: "left",
  key: "ref_url"
};

export const login_ip_addr = {
  title: "地域",
  width: 160,
  key: "login_ip_addr"
};

/*************  figurePeakCols  字段  *************/

export const num_max = {
  title: "峰值并发",
  width: 70,
  align: "center",
  key: "num_max",
  render(h, {
    row,
    column,
    index
  }) {
    return util.renderRoomRunningBtn(
      h,
      row.num_max,
      (row.room_id ?
        types.renderStrByTag("room", row.room, "并发数据") :
        types.renderStrByTag("admin", row.admin, "并发数据")) + " " + dms.date("Y-m-d", util.intday2time(row.per_day)),
      row.room_id || 0,
      row.admin_id || 0, {
        stime: util.intday2time(row.per_day),
        etime: util.intday2time(row.per_day) + 24 * 3600
      }
    );
  }
};

export const num_max_time = {
  title: "峰值时刻",
  width: 155,
  align: "center",
  key: "num_max_time"
};

export const hw_num_max = {
  title: "海外并发",
  width: 70,
  align: "center",
  key: "hw_num_max",
  render(h, {
    row,
    column,
    index
  }) {
    return util.renderRoomRunningBtn(
      h,
      row.hw_num_max,
      (row.room_id ?
        types.renderStrByTag("room", row.room, "海外并发数据") :
        types.renderStrByTag("admin", row.admin, "海外并发数据")) + " " + dms.date("Y-m-d", util.intday2time(row.per_day)),
      row.room_id || 0,
      row.admin_id || 0, {
        stime: util.intday2time(row.per_day),
        etime: util.intday2time(row.per_day) + 24 * 3600,
        useHw: 1
      },
      row.hw_flow_up_total,
      row.hw_flow_down_total
    );
  }
};

export const flow_down_total = {
  title: "总流量",
  width: 90,
  align: "center",
  key: "flow_down_total",
  render(h, {
    row,
    column,
    index
  }) {
    var total = row.flow_down_total + row.flow_up_total;
    var ok = row.flow_down_total_ok + row.flow_up_total_ok;

    return util.renderFlowBtn(
      h,
      util.byte2size(total),
      (row.room_id ?
        types.renderStrByTag("room", row.room, "流量数据") :
        types.renderStrByTag("admin", row.admin, "流量数据")) + " " + dms.date("Y-m-d", util.intday2time(row.per_day)),
      row.room_id || 0,
      row.admin_id || 0, {
        stime: util.intday2time(row.per_day),
        etime: util.intday2time(row.per_day) + 24 * 3600
      }, {
        useEx: true,
        title: "总流量：" +
          util.byte2size(total) +
          "(" + util.byte2size(ok) + ")" +
          ", 上行流量:" +
          util.byte2size(row.flow_up_total) +
          "(" + util.byte2size(row.flow_up_total_ok) + ")" +
          ", 下行流量:" +
          util.byte2size(row.flow_down_total) +
          "(" + util.byte2size(row.flow_down_total_ok) + ")"
      }
    );
  }
};

export const hw_flow_down_total = {
  title: "海外流量",
  width: 90,
  align: "center",
  key: "hw_flow_down_total",
  render(h, {
    row,
    column,
    index
  }) {
    var total = row.hw_flow_down_total + row.hw_flow_up_total;
    var ok = row.hw_flow_down_total_ok + row.hw_flow_up_total_ok;
    if (!issuper) {
      return h('span', util.byte2size(total));
    }

    return util.renderFlowBtn(
      h,
      util.byte2size(total),
      (row.room_id ?
        types.renderStrByTag("room", row.room, "海外流量") :
        types.renderStrByTag("admin", row.admin, "海外流量")) + " " + dms.date("Y-m-d", util.intday2time(row.per_day)),
      row.room_id || 0,
      row.admin_id || 0, {
        stime: util.intday2time(row.per_day),
        etime: util.intday2time(row.per_day) + 24 * 3600
      }, {
        isHw: true,
        title: "海外总流量：" +
          util.byte2size(total) +
          "(" + util.byte2size(ok) + ")" +
          ", 上行流量:" +
          util.byte2size(row.hw_flow_up_total) +
          "(" + util.byte2size(row.hw_flow_up_total_ok) + ")" +
          ", 下行流量:" +
          util.byte2size(row.hw_flow_down_total) +
          "(" + util.byte2size(row.hw_flow_down_total_ok) + ")"
      }
    );
  }
};

export const vss_down_total = {
  title: "VSS点播流量",
  width: 90,
  align: "center",
  key: "vss_down_total",
  render(h, {
    row,
    column,
    index
  }) {
    var total = row.vss_up_total + row.vss_down_total;
    var ok = row.vss_up_total_ok + row.vss_down_total_ok;
    if (!issuper) {
      return h('span', util.byte2size(total));
    }

    return util.renderFlowBtn(
      h,
      util.byte2size(total),
      (row.room_id ?
        types.renderStrByTag("room", row.room, "永久存储点播流量") :
        types.renderStrByTag("admin", row.admin, "永久存储点播流量")) + " " + dms.date("Y-m-d", util.intday2time(row.per_day)),
      row.room_id || 0,
      row.admin_id || 0, {
        stime: util.intday2time(row.per_day),
        etime: util.intday2time(row.per_day) + 24 * 3600
      }, {
        flowType: "vss",
        title: "永久存储点播总流量：" +
          util.byte2size(total) +
          "(" + util.byte2size(ok) + ")" +
          ", 上行流量:" +
          util.byte2size(row.vss_up_total) +
          "(" + util.byte2size(row.vss_up_total_ok) + ")" +
          ", 下行流量:" +
          util.byte2size(row.vss_down_total) +
          "(" + util.byte2size(row.vss_down_total_ok) + ")"
      }
    );
  }
};

export const tmp_vss_down_total = {
  title: "TMP点播流量",
  width: 90,
  align: "center",
  key: "tmp_vss_down_total",
  render(h, {
    row,
    column,
    index
  }) {
    var total = row.tmp_vss_up_total + row.tmp_vss_down_total;
    var ok = row.tmp_vss_up_total_ok + row.tmp_vss_down_total_ok;
    if (!issuper) {
      return h('span', util.byte2size(total));
    }

    return util.renderFlowBtn(
      h,
      util.byte2size(total),
      (row.room_id ?
        types.renderStrByTag("room", row.room, "临时存储点播流量") :
        types.renderStrByTag("admin", row.admin, "临时存储点播流量")) + " " + dms.date("Y-m-d", util.intday2time(row.per_day)),
      row.room_id || 0,
      row.admin_id || 0, {
        stime: util.intday2time(row.per_day),
        etime: util.intday2time(row.per_day) + 24 * 3600
      }, {
        flowType: "tmp",
        title: "临时存储点播总流量" +
          util.byte2size(total) +
          "(" + util.byte2size(ok) + ")" +
          ", 上行流量:" +
          util.byte2size(row.tmp_vss_up_total) +
          "(" + util.byte2size(row.tmp_vss_up_total_ok) + ")" +
          ", 下行流量:" +
          util.byte2size(row.tmp_vss_down_total) +
          "(" + util.byte2size(row.tmp_vss_down_total_ok) + ")"
      }
    );
  }
};

export const cloud_space_total_size = {
  title: "总存储空间",
  width: 90,
  align: "center",
  key: "cloud_space_total_size",
  render(h, {
    row,
    column,
    index
  }) {
    return h("Span", [
      util.byte2size(row.cloud_space_total_size)
    ]);
  }
};

export const flow_pre_num = {
  title: "单位流量",
  width: 120,
  align: "center",
  key: "flow_pre_num",
  render(h, {
    row,
    column,
    index
  }) {
    var d = row.flow_pre_num / 1024 / 1024 / 1024;
    var p24 = d * 0.2 * 24;
    var p30 = d * 0.2 * 30;
    return h("Span", {
      attrs: {
        title: "估算成本(24天/月)：" + p24.toFixed(2) + "元" + ", 成本(30天/月)：" + p30.toFixed(2) + "元"
      },
      style: {
        color: d >= 1.04 ? types.C_Error : (d >= 0.625 ? types.C_Warning : types.C_Normal)
      }
    }, util.byte2size(row.flow_pre_num) + " / " + p24.toFixed(2) + "元");
  }
}

export const package_num_price = {
  title: "单价/毛利率",
  width: 120,
  align: "center",
  key: "package_num_price",
  render(h, {
    row,
    column,
    index
  }) {
    var d = row.flow_pre_num / 1024 / 1024 / 1024;
    var p24 = d * 0.2 * 24;

    var color = types.C_Normal;
    if (row.package_num_price > 0) {
      if (p24 <= 0.5 * row.package_num_price) {
        color = types.C_Success;
      }
      if (p24 >= 0.8 * row.package_num_price) {
        color = types.C_Warning;
      }
      if (p24 >= row.package_num_price) {
        color = types.C_Error;
      }
    }
    var v24 = 0;
    var n24 = 0;
    if (row.package_num_price > 0) {
      n24 = row.package_num_price - p24;
      v24 = n24 / row.package_num_price * 100;
    }
    return h("Span", {
      attrs: {
        title: "估算成本(24天/月)：" + p24.toFixed(2) + "元" + (v24 != 0 ? ", 毛利率：" + v24.toFixed(2) + "%, 毛利：" + n24.toFixed(2) + "元" : "")
      },
      style: {
        color: color
      }
    }, row.package_num_price.toFixed(2) + "元" + " / " + (v24 != 0 ? v24.toFixed(2) + "%" : "-"));
  }
}

export const hw_num_max_time = {
  title: "海外峰值时刻",
  width: 155,
  align: "center",
  key: "hw_num_max_time"
};

export const total_unique_user = {
  title: "用户总数",
  width: 90,
  align: "center",
  key: "total_unique_user"
};

export const total_ip = {
  title: "IP总数",
  width: 90,
  align: "center",
  key: "total_ip"
};

export const view_count = {
  title: "点击数",
  width: 90,
  align: "center",
  key: "view_count"
};

export const total_interval_time = {
  title: "观看总时长",
  width: 120,
  align: "center",
  key: "total_interval_time",
  render(h, {
    row,
    column,
    index
  }) {
    return util.renderIntervalTime(h, row.total_interval_time);
  }
};

export const total_view_record = {
  title: "观看记录数",
  width: 90,
  align: "center",
  key: "total_view_record"
};

export const total_unique_user_ip_view_count_interval_time_view_record = [
  total_unique_user,
  total_ip,
  view_count,
  total_interval_time,
  total_view_record
];

/******* cashRunningCols 字段   *******/

export const package_num = {
  title: "套餐限额",
  width: 120,
  align: "center",
  key: "package_num",
  render(h, {
    row,
    column,
    index
  }) {
    return util.renderPackageListBtn(h,
      row.package_num,
      types.renderStrByTag("admin", row.admin, "套餐列表") + " " + dms.date("Y-m-d", util.intday2time(row.per_day)), {
        admin_id: row.admin_id || 0,
        per_day: row.per_day,
      }, {
        product_price: user.admin_type == "super",
        expired_days: user.admin_type == "super",
      });
  }
};

export const over_price_num = {
  title: "超出部分",
  width: 120,
  align: "center",
  key: "over_price_num",
  render(h, {
    row,
    column,
    index
  }) {
    return h("Span", [
      row.num_max > row.package_num ? row.num_max - row.package_num : "-"
    ]);
  }
};

export const over_price = {
  title: "超出部分价格",
  width: 120,
  align: "center",
  key: "over_price",
  render(h, {
    row,
    column,
    index
  }) {
    return h("Span", parseFloat(row.over_price).toFixed(2));
  }
};


/************* cashPackageCols  字段  **********/

export const package_name = {
  title: "套餐名称",
  width: 120,
  align: "center",
  key: "package_name",
  render(h, {
    row,
    column,
    index
  }) {
    var tmp = JSON.parse(row.product_value);
    return h("Span", tmp.product_title);
  }
};

export const package_type = {
  title: "套餐类型",
  width: 100,
  align: "center",
  key: "package_type",
  render(h, {
    row,
    column,
    index
  }) {
    var tmp = JSON.parse(row.product_value);
    return util.renderEnum(h, tmp.limit_type, types.PackageLimitType);
  }
};

export const package_limit = {
  title: "套餐额度",
  width: 100,
  align: "center",
  key: "package_limit",
  render(h, {
    row,
    column,
    index
  }) {
    var tmp = JSON.parse(row.product_value);
    return h("Span", tmp.limit_type == "hwflow" ? util.byte2size(tmp.limit_value) : tmp.limit_value);
  }
};

export const package_state = {
  title: "套餐状态",
  width: 100,
  align: "center",
  key: "package_state",
  render(h, {
    row,
    column,
    index
  }) {
    return util.renderEnum(h, row.state || NORMAL, types.PackageStateEnum);
  }
};

export const expired_days = {
  title: "有效期",
  key: "expired_days",
  width: 80,
  align: "center"
};

export const start_time = {
  title: "起始日期",
  width: 155,
  align: "center",
  key: "start_time",
  render(h, {
    row,
    column,
    index
  }) {
    return h("Span", [dms.date("Y-m-d", dms.strtotime(row.start_time))]);
  }
};

export const end_time = {
  title: "截止日期",
  width: 155,
  align: "center",
  key: "end_time",
  render(h, {
    row,
    column,
    index
  }) {
    return h("Span", [
      dms.date(
        "Y-m-d",
        dms.strtotime(row.start_time) + row.expired_days * 24 * 3600
      )
    ]);
  }
};

export const start_time_end_time = [start_time, end_time];

/*********   cashPurchaseCols 字段 ************/
export const order_id = {
  title: "订单ID",
  tag: "id",
  width: 80,
  align: "center",
  key: "order_id"
};

export const order_type = {
  title: "订单类型",
  width: 110,
  align: "center",
  key: "order_type",
  render(h, {
    row,
    column,
    index
  }) {
    return util.renderEnum(h, row.order_type, types.OrderType);
  }
};

export const order_money = {
  title: "订单金额",
  key: "order_money",
  width: 110,
  align: "center",
  render(h, {
    row,
    column,
    index
  }) {
    return h("span", [
      row.order_money >= 0 ? "充值 " : "扣除 ",
      parseFloat(Math.abs(row.order_money)).toFixed(2),
      "元"
    ]);
  }
};

export const order_note = {
  title: "订单信息",
  key: "order_note",
  width: 200,
  align: "center"
};

export const account_balance_after = {
  title: "余额",
  key: "account_balance_after",
  width: 90,
  align: "center",
  render(h, {
    row,
    column,
    index
  }) {
    return h("span", [parseFloat(row.account_balance_after).toFixed(2), "元"]);
  }
};

/*********   siteMgrCols 字段 ************/

export const mgr_id = {
  title: "管理员ID",
  key: "mgr_id",
  tag: "id",
  width: 70,
  align: "center",
  fixed: "left"
};

export const mgr_slug = {
  title: "类型",
  key: "mgr_slug",
  width: 100,
  align: "center",
  render(h, {
    row,
    column,
    index
  }) {
    var cfg = types.MgrSlugEnum[row.mgr_slug] || types.MgrSlugEnum.UNKNOWN;

    return h(
      "span", {
        style: {
          color: cfg.c
        }
      },
      cfg.t
    );
  }
};

export const login_count = {
  title: "登录次数",
  key: "login_count",
  width: 90,
  align: "center"
};

/************播放器列表字段***************/
export const player_id = {
  title: "播放器ID",
  key: "player_id",
  tag: "id",
  width: 90,
  align: "center",
  fixed: "left"
};

export const player_name = {
  title: "播放器名称",
  key: "player_name",
  width: 120,
  align: "center",
  fixed: "left"
};

/*********** 其它 字段  *************/

import menuAcl_ from "@/components/widget/menuAcl";

export const menuAcl = {
  title: "权限",
  key: "menuAcl",
  width: 470,
  render(h, {
    row,
    column,
    index
  }) {
    var editACL = pageInfo.appRouterAllACL[row.admin_type.toLocaleLowerCase()];
    var menu = util.buildMap(row.menuAcl);
    return h(menuAcl_, {
      props: {
        editACL: editACL,
        editACL_val: util.buildMenuACLBase(editACL, menu)
      }
    });
  }
};

export const playerAcl_enable_empty_ref_type_hosts = [{
    title: "是否开启",
    key: "playerAcl.enable",
    width: 80,
    align: "center",
    render(h, {
      row,
      column,
      index
    }) {
      return h(
        "Span", {
          style: {
            color: row.playerAcl.enable ? types.C_Success : types.C_Warning
          }
        },
        row.playerAcl.enable ? "开启" : "关闭"
      );
    }
  },
  {
    title: "ref是否允许为空",
    key: "playerAcl.empty_ref",
    width: 100,
    align: "center",
    render(h, {
      row,
      column,
      index
    }) {
      return h(
        "Span", {
          style: {
            color: row.playerAcl.empty_ref ? types.C_Success : types.C_Warning
          }
        },
        row.playerAcl.empty_ref ? "可为空" : "非空"
      );
    }
  },
  {
    title: "类型",
    key: "playerAcl.type",
    width: 100,
    align: "center",
    render(h, {
      row,
      column,
      index
    }) {
      return h("Span", row.playerAcl.type == "whitelist" ? "白名单" : "黑名单");
    }
  },
  {
    title: "域名列表",
    key: "playerAcl.hosts",
    width: 150,
    align: "center",
    render(h, {
      row,
      column,
      index
    }) {
      return h(
        "Span", {
          style: {
            color: "green",
            "white-space": "pre-wrap"
          }
        },
        row.playerAcl.hosts || ""
      );
    }
  }
];

export const lss_player_bufferlength_maxbufferlength_scaling_fullscreen = [{
    title: "ios自动播放",
    key: "bufferAcl.try_ios_autoplay",
    width: 80,
    align: "center",
    render(h, {
      row,
      column,
      index
    }) {
      return h(
        "Span", {
          style: {
            color: row.bufferAcl.try_ios_autoplay ? types.C_Success : types.C_Warning
          }
        },
        row.bufferAcl.try_ios_autoplay ? "开启" : "关闭"
      );
    }
  },
  {
    title: "安卓自动播放",
    key: "bufferAcl.try_android_autoplay",
    width: 80,
    align: "center",
    render(h, {
      row,
      column,
      index
    }) {
      return h(
        "Span", {
          style: {
            color: row.bufferAcl.try_android_autoplay ? types.C_Success : types.C_Warning
          }
        },
        row.bufferAcl.try_android_autoplay ? "开启" : "关闭"
      );
    }
  },
  {
    title: "循环播放点播",
    key: "bufferAcl.try_vod_loop",
    width: 80,
    align: "center",
    render(h, {
      row,
      column,
      index
    }) {
      return h(
        "Span", {
          style: {
            color: row.bufferAcl.try_vod_loop ? types.C_Success : types.C_Warning
          }
        },
        row.bufferAcl.try_vod_loop ? "开启" : "关闭"
      );
    }
  }, {
    title: "播放器缓冲区",
    key: "bufferAcl.lss_player_bufferlength",
    width: 80,
    align: "center",
    render(h, {
      row,
      column,
      index
    }) {
      return h(
        "Span", {},
        row.bufferAcl.lss_player_bufferlength + " s"
      );
    }
  },
  {
    title: "播放器最大缓冲区",
    key: "bufferAcl.lss_player_maxbufferlength",
    width: 80,
    align: "center",
    render(h, {
      row,
      column,
      index
    }) {
      return h(
        "Span", {},
        row.bufferAcl.lss_player_maxbufferlength + " s"
      );
    }
  },
  {
    title: "播放器缓冲显示",
    key: "bufferAcl.lss_player_isloadcount",
    width: 80,
    align: "center",
    render(h, {
      row,
      column,
      index
    }) {
      return h(
        "Span", {},
        row.bufferAcl.lss_player_isloadcount + " s"
      );
    }
  },
  {
    title: "全屏模式",
    key: "bufferAcl.lss_player_scaling",
    width: 80,
    align: "center",
    render(h, {
      row,
      column,
      index
    }) {
      return h(
        "Span", {},
        row.bufferAcl.lss_player_scaling == 1 ? "按比例撑满全屏" : (row.bufferAcl.lss_player_scaling == 2 ? "铺满全屏" : "视频原始大小")
      );
    }
  },
  {
    title: "手机全屏播放",
    key: "bufferAcl.lss_player_m_fullscreen",
    width: 80,
    align: "center",
    render(h, {
      row,
      column,
      index
    }) {
      return h(
        "Span", {
          style: {
            color: row.bufferAcl.lss_player_m_fullscreen ? types.C_Success : types.C_Warning
          }
        },
        row.bufferAcl.lss_player_m_fullscreen ? "开启" : "关闭"
      );
    }
  }, {
    title: "js嵌入 播放resize",
    key: "bufferAcl.js_play_resize",
    width: 80,
    align: "center",
    render(h, {
      row,
      column,
      index
    }) {
      return h(
        "Span", {
          style: {
            color: row.bufferAcl.js_play_resize ? types.C_Success : types.C_Warning
          }
        },
        row.bufferAcl.js_play_resize ? "开启" : "关闭"
      );
    }
  }
]

export const noticeAcl_config = [{
    title: "套餐超出提醒是否开启",
    key: "noticeAcl.enableOver",
    width: 80,
    align: "center",
    render(h, {
      row,
      column,
      index
    }) {
      return h(
        "Span", {
          style: {
            color: row.noticeAcl.enableOver ? types.C_Success : types.C_Warning
          }
        },
        row.noticeAcl.enableOver ? "开启" : "关闭"
      );
    }
  },
  {
    title: "套餐过期提醒是否开启",
    key: "noticeAcl.enableExpired",
    width: 80,
    align: "center",
    render(h, {
      row,
      column,
      index
    }) {
      return h(
        "Span", {
          style: {
            color: row.noticeAcl.enableExpired ? types.C_Success : types.C_Warning
          }
        },
        row.noticeAcl.enableExpired ? "开启" : "关闭"
      );
    }
  },
  {
    title: "欠费提醒是否开启",
    key: "noticeAcl.enableArrears",
    width: 80,
    align: "center",
    render(h, {
      row,
      column,
      index
    }) {
      return h(
        "Span", {
          style: {
            color: row.noticeAcl.enableArrears ? types.C_Success : types.C_Warning
          }
        },
        row.noticeAcl.enableArrears ? "开启" : "关闭"
      );
    }
  },
  {
    title: "短信通知时间设置",
    key: "noticeAcl.notifyTime",
    width: 100,
    align: "center",
    render(h, {
      row,
      column,
      index
    }) {
      return h(
        "Span", {
          style: {
            color: row.noticeAcl.notifyTime ? types.C_Success : types.C_Warning
          }
        },
        row.noticeAcl.notifyTime
      );
    }
  },
  {
    title: "套餐超出提醒间隔",
    key: "noticeAcl.intervalOver",
    width: 100,
    align: "center",
    render(h, {
      row,
      column,
      index
    }) {
      return h("Span", row.noticeAcl.intervalOver);
    }
  },
  {
    title: "套餐过期提醒间隔",
    key: "noticeAcl.intervalExpired",
    width: 150,
    align: "center",
    render(h, {
      row,
      column,
      index
    }) {
      return h(
        "Span", {
          style: {
            color: "green",
            "white-space": "pre-wrap"
          }
        },
        row.noticeAcl.intervalExpired || ""
      );
    }
  },
  {
    title: "欠费提醒间隔",
    key: "noticeAcl.intervalArrears",
    width: 150,
    align: "center",
    render(h, {
      row,
      column,
      index
    }) {
      return h(
        "Span", {
          style: {
            color: "green",
            "white-space": "pre-wrap"
          }
        },
        row.noticeAcl.intervalArrears || ""
      );
    }
  }
];

/*
  "track_sessions" => 1,  // 跟踪会话  默认为 1
  "track_pageview" => 0,  // 跟踪页面浏览数  默认为 0
  "track_clicks" => 0,  // 跟踪点击(企业版)  默认为 0
  "track_links" => 0,  // 跟踪链接点击  默认为 0
  "track_forms" => 0,  // 跟踪表单提交  默认为 0
  "track_errors" => 0,  // 记录 js 错误  默认为 0
  "qos_duration" => 60,  // hts 报告 缓冲数据 单位时间  默认为 60
  "pc_loading" => 1,  // 是否上报 pc 单位时间内 缓冲数据  默认为 0
  "mobile_loading" => 1,  // 是否上报 mobile 单位时间内 缓冲数据
*/

export const qos_acl_cols = [{
    title: "跟踪会话",
    key: "track_sessions"
  },
  {
    title: "跟踪页面浏览数",
    key: "track_pageview"
  },
  {
    title: "跟踪点击(企业版)",
    key: "track_clicks"
  },
  {
    title: "跟踪链接点击",
    key: "track_links"
  },
  {
    title: "跟踪表单提交",
    key: "track_forms"
  },
  {
    title: "记录 js 错误",
    key: "track_errors"
  },
  {
    title: "上报 单位时间",
    key: "qos_duration"
  },
  {
    title: "上报 pc 缓冲数据",
    key: "pc_loading"
  },
  {
    title: "上报 mobile 缓冲数据",
    key: "mobile_loading"
  },
  {
    title: "DMS pc 缓冲数据",
    key: "pc_dms_loading"
  },
  {
    title: "DMS mobile 缓冲数据",
    key: "mobile_dms_loading"
  },
].map(item => {
  var args = {
    title: item.title,
    key: "qosAcl." + item.key,
    width: item.width || 80,
    align: item.align || "center"
  };

  return item.key == "qos_duration" ? {
    ...args,
    render(h, {
      row,
      column,
      index
    }) {
      return h(
        "Span", {},
        row.qosAcl[item.key] + " s"
      );
    }
  } : {
    ...args,
    render(h, {
      row,
      column,
      index
    }) {
      return h(
        "Span", {
          style: {
            color: row.qosAcl[item.key] ? types.C_Success : types.C_Warning
          }
        },
        row.qosAcl[item.key] ? "开启" : "关闭"
      );
    }
  }
})

/** MCS log */

export const mcs_push_log_cols = [{
    title: "ID",
    key: "id",
    width: 80,
  },
  {
    title: "视频流ID",
    key: "stream_id",
    width: 70,
  },
  admin_title,
  admin_agent_title,
  {
    ...stream_mcs_account,
    editable: false
  }, {
    title: "时间",
    key: "time_stamp_str",
    width: 130,
    renderVal(row) {
      return row.time_stamp ? (dms.date('m-d H:i:s', row.time_stamp) + '.' + row.time_stamp % 1000) : '-';
    }
  }, {
    title: "KEY",
    key: "key_str",
    width: 140,
    ellipsis: true
  }, {
    title: "参数",
    key: "segmentation",
    width: 190,
    ellipsis: true
  }
];

/** 导播台*/
export const caster_id = {
  title: "导播台ID",
  key: "caster_id",
  width: 300,
  render(h, {
    row,
    column,
    index
  }) {
    return h(
      "Span",
      row.stream ? row.stream.caster_id : ''
    );
  }
};

export const limit_caster_price = {
  title: "分钟价格(每分钟)",
  key: "limit_caster_price",
  width: 150,
  editable: issuper ? true : false,
  align: "left",
  renderVal: row => {
    return row.stream ? row.stream.limit_caster_price : "";
  },
};

export const charging_mode = {
  title: "收费模式(1 按分钟计费 2 周期计费)",
  key: "charging_mode",
  width: 150,
  editable: issuper ? true : false,
  align: "left",
  renderVal: row => {
    return row.stream ? row.stream.charging_mode : 1;
  },
};

export const limit_perid_caster_price = {
  title: "周期价格(每周期)",
  key: "limit_perid_caster_price",
  width: 150,
  editable: issuper ? true : false,
  align: "left",
  renderVal: row => {
    return row.stream ? row.stream.limit_perid_caster_price : "";
  },
};

export const caster_name = {
  title: "导播台名称",
  key: "caster_name",
  width: 300,
  render(h, {
    row,
    column,
    index
  }) {
    return h(
      "Span",
      row.stream ? row.stream.caster_name : ''
    );
  }
};

export const init_caster = {
  title: "进入导播台",
  key: "init_caster",
  width: 150,
  align: "center",
  render(h, {
    row,
    column,
    index
  }) {
    if (row.admin == undefined) {
      return '';
    }
    return h(
      "A", {
        attrs: {
          href: '/' + user.admin_type + '#/caster?admin_id=' + row.admin.admin_id + '&caster_id=' + row.stream.caster_id,
          target: '_blank'
        }
      },
      "进入导播台"
    );
  }
}
export const charge_type = {
  title: "charge_type",
  key: "charge_type",
  width: 150,
  render(h, {
    row,
    column,
    index
  }) {
    return h(
      "Span",
      row.stream ? row.stream.charge_type : ''
    );
  }
};
export const create_time = {
  title: "创建时间",
  key: "create_time",
  width: 150,
  render(h, {
    row,
    column,
    index
  }) {
    return h(
      "Span",
      row.stream ? row.stream.create_time : ''
    );
  }
};
export const norm_type = {
  title: "norm_type",
  key: "norm_type",
  width: 150,
  render(h, {
    row,
    column,
    index
  }) {
    return h(
      "Span",
      row.stream ? row.stream.norm_type : ''
    );
  }
};
export const caster_status = {
  title: "Status",
  key: "caster_status",
  width: 150,
  render(h, {
    row,
    column,
    index
  }) {
    return h(
      "Span",
      row.stream ? row.stream.caster_status : ''
    );
  }
};

export const last_room_id = {
  title: "room_id",
  key: "last_room_id",
  width: 150,
  render(h, {
    row,
    column,
    index
  }) {
    return h(
      "Span",
      row.stream ? row.stream.last_room_id : ''
    );
  }
};
export const caster_config = {
  title: "导播台配置",
  key: "caster_config",
  width: 150,
  render(h, {
    row,
    column,
    index
  }) {
    return h(
      "Span",
      row.stream ? row.stream.caster_config : ''
    );
  }
};