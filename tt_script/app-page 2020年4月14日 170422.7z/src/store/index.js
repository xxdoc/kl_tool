import Vue from "vue";
import Vuex from "vuex";
import * as types from "@/types";

import app from "@/store/modules/app";
import user from "@/store/modules/user";
import mutations from "@/store/mutations";
import actions from "@/store/actions";
import getters from "@/store/getters";

Vue.use(Vuex);

const base_message = (vm, slug, content, autoClose, callback) => {
  vm.$store.commit(types.SPIN_SHOW, false);

  slug = slug || 'success';
  autoClose = autoClose || 0;

  var args = {
    duration: slug == 'success' && autoClose == 0 ? 1.5 : autoClose,
    content: content || "操作成功",
    onClose: () => {
      typeof callback == 'function' && callback();
    }
  };

  setTimeout(() => {
    (vm.$Message[slug])(args);
  }, 200);
}

const base_notice = (vm, slug, title, content, autoClose, callback) => {
  vm.$store.commit(types.SPIN_SHOW, false);
  slug = slug || 'success';
  autoClose = autoClose || 0;

  var args = {
    title: title || "成功",
    desc: content || "操作成功",
    duration: slug == 'success' && autoClose == 0 ? 4.5 : autoClose,
    onClose: () => {
      typeof callback == 'function' && callback();
    }
  };

  setTimeout(() => {
    (vm.$Notice[slug])(args);
  }, 200);
}

const base_modal = (vm, slug, title, content, okText, autoClose, callback) => {
  vm.$store.commit(types.SPIN_SHOW, false);
  slug = slug || 'success';
  autoClose = autoClose || 0;
  var args = {
    title: title || "成功",
    content: content || "操作成功",
    okText: okText || "确定",
    onOk: () => {
      typeof callback == 'function' && callback();
    }
  };

  setTimeout(() => {
    if (autoClose > 0) {
      setTimeout(() => {
        vm.$Modal.remove();
        typeof callback == 'function' && callback();
      }, autoClose);
    }

    (vm.$Modal[slug])(args);
  }, 200);
}

Vue.mixin({
  computed: {
    ...Vuex.mapGetters([types._size, types.D, types.user])
  },
  methods: {
    _success(res, type, callback) {
      type = type || 'modal';
      type = type.toLowerCase();

      if (type == 'modal') {
        return base_modal(this, 'success', res.title || "成功", res.msg || "操作成功", "2s自动关闭", 2200, callback);
      } else if (type == 'msg' || type == 'message') {
        return base_message(this, 'success', res.msg || "操作成功", 2.2, callback);
      } else if (type == 'tips' || type == 'notice') {
        return base_notice(this, 'success', res.title || "成功", res.msg || "操作成功", 4.5, callback);
      }

      return base_modal(this, 'success', res.title || "成功", res.msg || "操作成功", "2s自动关闭", 2200, callback);
    },
    _error(res, type, callback) {
      dms.debug && console.error(res);

      type = type || 'modal';
      type = type.toLowerCase();

      if (type == 'modal') {
        return base_modal(this, 'error', res.title || "错误", res.msg || "操作失败", "确定", 0, callback);
      } else if (type == 'msg' || type == 'message') {
        return base_message(this, 'error', res.msg || "操作失败", 0, callback);
      } else if (type == 'tips' || type == 'notice') {
        return base_notice(this, 'success', res.title || "错误", res.msg || "操作失败", 0, callback);
      }

      return base_modal(this, 'error', res.title || "错误", res.msg || "操作失败", "确定", 0, callback);
    },
    _modal(slug, title, content, okText, autoClose, callback) {
      return base_modal(this, slug, title, content, okText, autoClose, callback);
    }
  }
});

const state = {
  [types.D]: {
    ...(window[types.D] || {}),
    clientWidth: document.documentElement.clientWidth,
    clientHeight: document.documentElement.clientHeight
  }
};

const modules = {
  app,
  user
};

export default new Vuex.Store({
  state,
  modules,
  mutations,
  actions,
  getters
});