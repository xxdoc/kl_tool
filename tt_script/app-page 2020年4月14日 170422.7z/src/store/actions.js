import * as types from "@/types";

var resizeTimer = null;

export default {
  [types.INIT_APP]({
    commit,
    state
  }, {
    client,
    dataIdFromObject
  }) {

    $(window).resize(
      () => {
        if (resizeTimer) {
          clearTimeout(resizeTimer)
        }
        resizeTimer = setTimeout(() => {
          types.onResize(state);
        }, 200)
      }
    );

    dms.onMsg(
      "reload_page",
      (topic, dmsData) => {
        location.reload(true);
      },
      (topic, dmsData) => {
        return dmsData.uid == state.user.uid;
      }
    );
  }
};