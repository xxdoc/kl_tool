import Cookies from "js-cookie";
import * as types from "@/types";

export default {
  state: {
    ...(window[types.user] || {})
  }
};