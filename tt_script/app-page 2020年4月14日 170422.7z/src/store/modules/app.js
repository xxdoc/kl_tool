import Util from "@/libs/util";
import Cookies from "js-cookie";
import Vue from "vue";
import * as types from "@/types";

export default {
  state: {
    lang: ""
  },
  getters: {
  },
  mutations: {
  }
};