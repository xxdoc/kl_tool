import Vue from "vue";
import * as types from "@/types";

export default {
  [types.UPDATE_USER](state, payload) {
    Object.keys(payload).map(k => {
      var tmp = dms.deepExtend(state.user[k], payload[k]);
      Vue.set(state.user, k, tmp);
      if (Object.prototype.toString.call(tmp) === "[object Object]") {
        Object.keys(tmp).map(kk => {
          Vue.set(state.user[k], kk, tmp[kk]);
        });
      }
    });
  },
  [types.UPDATE_APP](state, payload) {
    Object.keys(payload).map(k => {
      var tmp = dms.deepExtend(state.app[k], payload[k]);
      Vue.set(state.app, k, tmp);
      if (Object.prototype.toString.call(tmp) === "[object Object]") {
        Object.keys(tmp).map(kk => {
          Vue.set(state.app[k], kk, tmp[kk]);
        });
      }
    });
  }
};