import * as types from "@/types";
import util from "@/libs/util.js";

export default {
  [types.isMobile](state) {
    return state.D.device_type != 'pc';
  },
  [types.D](state) {
    return {
      ...state.D,
      types: {
      },
      util:{
        byte2size: util.byte2size
      }
    };
  },
  [types._size](state) {
    let clientWidth = state.D.clientWidth;
    let clientHeight = state.D.clientHeight;

    return {
      clientWidth,
      clientHeight
    };
  },
  [types.user](state) {
    return {
      ...state.user
    };
  }
};