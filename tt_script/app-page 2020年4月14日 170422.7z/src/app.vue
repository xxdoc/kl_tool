<style>
html,
body {
  width: 100%;
  height: 100%;
  background: #f0f0f0;
  overflow: hidden;
}

.app-main {
  width: 100%;
  height: 100%;
}
.ivu-modal .ivu-select-dropdown {
  position: fixed !important;
}
.ivu-modal .ivu-page {
  margin-bottom: 0px !important;
}
</style>

<template>
  <div id="main" class="app-main">
    <router-view></router-view>
  </div>
</template>

<script>
export default {};
</script>