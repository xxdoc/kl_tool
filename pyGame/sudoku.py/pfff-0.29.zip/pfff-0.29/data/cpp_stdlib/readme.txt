You can also cp -a /usr/include/c++/.../ and /usr/include/boost wherever
your project is.
