package com.android.testing.dummyime;
class ImePreferences {
}
class DummyIme {
}
