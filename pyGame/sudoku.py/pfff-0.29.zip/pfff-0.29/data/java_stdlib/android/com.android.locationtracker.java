package com.android.locationtracker;
class TrackerService {
  class PreferenceListener {
  }
  class NetworkStateBroadcastReceiver {
  }
  int mPhoneStateListener;
  class LocationTrackingListener {
  }
  int mPrefListener;
  int DEBUG_PREF;
  int SIGNAL_PREF;
  int NETWORK_PREF;
  int GPS_PREF;
  int MIN_DIS_PREF;
  int MIN_TIME_PREF;
  int DATA_CONN_PROVIDER_TAG;
  int WIFI_PROVIDER_TAG;
  int SIGNAL_PROVIDER_TAG;
  int CELL_PROVIDER_TAG;
  int mNetwork;
  int mNetworkLocation;
  int mTelephonyManager;
  int mTrackerData;
  int mTrackedProviders;
  int LOG_TAG;
  int mListeners;
}
class TrackerActivity {
  int mDataHelper;
  int LOG_TAG;
}
class SettingsActivity {
}
