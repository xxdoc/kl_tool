package com.android.batterywaster;
class BatteryWaster {
  class SpinThread {
    int mStop;
  }
  int mReceiver;
  int mWakeClickListener;
  int mClickListener;
  int mWaking;
  int mWasting;
  int mThread;
  int mPartialWakeLock;
  int mFilter;
  int mDateFormat;
  int mLog;
}
