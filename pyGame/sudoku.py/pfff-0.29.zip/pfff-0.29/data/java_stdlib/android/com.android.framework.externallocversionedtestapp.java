package com.android.framework.externallocversionedtestapp;
class ExternalLocVersionedTestAppActivity {
}
