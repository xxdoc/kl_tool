package com.android.framework.externalsharedpermsbttestapp;
class ExternalSharedPermsBTTest {
  int REQUEST_ENABLE_BT;
}
