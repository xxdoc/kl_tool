package com.android.telephonymockriltests.functional;
class SimpleTestUsingMockRil {
  int mRunner;
  int mMockRilCtrl;
  int TAG;
}
