package android.support.v4.os;
class ParcelableCompatCreatorHoneycombMR2 {
  int mCallbacks;
}
class ParcelableCompatCreatorHoneycombMR2Stub {
}
class ParcelableCompatCreatorCallbacks {
}
class ParcelableCompat {
  class CompatCreator {
    int mCallbacks;
  }
}
