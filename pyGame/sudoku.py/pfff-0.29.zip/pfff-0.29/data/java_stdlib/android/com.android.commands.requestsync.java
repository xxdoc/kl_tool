package com.android.commands.requestsync;
class RequestSync {
  int mExtras;
  int mAuthority;
  int mAccountType;
  int mAccountName;
  int mCurArgData;
  int mNextArg;
  int mArgs;
}
