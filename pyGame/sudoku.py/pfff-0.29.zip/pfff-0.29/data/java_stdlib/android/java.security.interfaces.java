package java.security.interfaces;
class RSAPublicKey {
  int serialVersionUID;
}
class RSAPrivateKey {
  int serialVersionUID;
}
class RSAPrivateCrtKey {
  int serialVersionUID;
}
class RSAMultiPrimePrivateCrtKey {
  int serialVersionUID;
}
class RSAKey {
}
class ECPublicKey {
  int serialVersionUID;
}
class ECPrivateKey {
  int serialVersionUID;
}
class ECKey {
}
class DSAPublicKey {
  int serialVersionUID;
}
class DSAPrivateKey {
  int serialVersionUID;
}
class DSAParams {
}
class DSAKeyPairGenerator {
}
class DSAKey {
}
