package com.android.systemui.power;
class PowerUI {
  int mIntentReceiver;
  int mBatteryLevelTextView;
  int mLowBatteryDialog;
  int mInvalidChargerDialog;
  int mLowBatteryReminderLevels;
  int mLowBatteryAlertCloseLevel;
  int mInvalidCharger;
  int mPlugType;
  int mBatteryStatus;
  int mBatteryLevel;
  int mHandler;
  int DEBUG;
  int TAG;
}
