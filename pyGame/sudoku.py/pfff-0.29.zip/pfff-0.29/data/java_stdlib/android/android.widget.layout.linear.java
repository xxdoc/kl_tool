package android.widget.layout.linear;
class WeightTest {
  int mContainer;
  int mChild;
}
class WeightSumTest {
  int mContainer;
  int mChild;
}
class WeightSum {
}
class Weight {
}
class LinearLayoutEditTextsTest {
  int mContainer;
  int mChild;
}
class LinearLayoutEditTexts {
}
class LLOfTwoFocusableInTouchMode {
  int mB3Fired;
  int mB2Fired;
  int mB1Fired;
  int mButton3;
  int mButton2;
  int mButton1;
}
class LLOfButtons2 {
}
class LLOfButtons1 {
  int mFirstButton;
  int mButtonPressed;
}
class LLEditTextThenButton {
  int mLayout;
  int mButton;
  int mEditText;
}
class HorizontalOrientationVerticalAlignment {
}
class FillInWrapTest {
  int mContainer;
  int mChild;
}
class FillInWrap {
}
class ExceptionTextView {
  int mFailed;
}
class BaselineButtonsTest {
  int mLayout;
  int mPause;
  int mNext;
  int mPrev;
  int mTotalTime;
  int mCurrentTime;
}
class BaselineButtons {
}
class BaselineAlignmentZeroWidthAndWeightTest {
  int mShowButton;
}
class BaselineAlignmentZeroWidthAndWeight {
}
class BaselineAlignmentSpinnerButton {
  int mButton;
  int mSpinner;
}
class BaselineAlignmentCenterGravityTest {
  int mButton3;
  int mButton2;
  int mButton1;
}
class BaselineAlignmentCenterGravity {
}
