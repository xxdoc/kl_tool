package com.android.internal.telephony.uicc;
class UiccController {
  int mIccCard;
  int mIsCurrentCard3gpp;
  int mCurrentPhone;
  int mInstance;
  int LOG_TAG;
  int DBG;
}
