package com.android.framework.externalloctestapp;
class ExternalLocTestAppActivity {
}
