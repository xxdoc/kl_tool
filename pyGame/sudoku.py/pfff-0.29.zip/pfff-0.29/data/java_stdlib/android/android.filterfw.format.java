package android.filterfw.format;
class PrimitiveFormat {
}
class ObjectFormat {
}
class ImageFormat {
  int COLORSPACE_YUV;
  int COLORSPACE_RGBA;
  int COLORSPACE_RGB;
  int COLORSPACE_GRAY;
  int COLORSPACE_KEY;
}
