package java.security.acl;
class Permission {
}
class Owner {
}
class NotOwnerException {
  int serialVersionUID;
}
class LastOwnerException {
  int serialVersionUID;
}
class Group {
}
class AclNotFoundException {
  int serialVersionUID;
}
class AclEntry {
}
class Acl {
}
