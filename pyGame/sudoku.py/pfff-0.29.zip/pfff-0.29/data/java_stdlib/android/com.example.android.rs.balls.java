package com.example.android.rs.balls;
class BallsView {
  int mRender;
  int mRS;
}
class BallsRS {
  int mVpConsts;
  int mPoints;
  int mPV;
  int mPFPoints;
  int mPFLines;
  int mPhysicsScript;
  int mScript;
  int mRS;
  int mRes;
  int PART_COUNT;
}
class Balls {
  int mSensorManager;
  int mView;
  int LOG_ENABLED;
  int DEBUG;
  int LOG_TAG;
}
