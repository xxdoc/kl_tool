package android.support.v7.gridlayout;
class R {
  class styleable {
    int GridLayout_Layout_layout_rowSpan;
    int GridLayout_Layout_layout_row;
    int GridLayout_Layout_layout_gravity;
    int GridLayout_Layout_layout_columnSpan;
    int GridLayout_Layout_layout_column;
    int GridLayout_Layout_android_layout_width;
    int GridLayout_Layout_android_layout_marginTop;
    int GridLayout_Layout_android_layout_marginRight;
    int GridLayout_Layout_android_layout_marginLeft;
    int GridLayout_Layout_android_layout_marginBottom;
    int GridLayout_Layout_android_layout_margin;
    int GridLayout_Layout_android_layout_height;
    int GridLayout_Layout;
    int GridLayout_useDefaultMargins;
    int GridLayout_rowOrderPreserved;
    int GridLayout_rowCount;
    int GridLayout_orientation;
    int GridLayout_columnOrderPreserved;
    int GridLayout_columnCount;
    int GridLayout_alignmentMode;
    int GridLayout;
  }
  class id {
    int vertical;
    int top;
    int start;
    int right;
    int left;
    int horizontal;
    int fill_vertical;
    int fill_horizontal;
    int fill;
    int end;
    int clip_vertical;
    int clip_horizontal;
    int center_vertical;
    int center_horizontal;
    int center;
    int bottom;
    int alignMargins;
    int alignBounds;
  }
  class dimen {
    int default_gap;
  }
  class attr {
    int useDefaultMargins;
    int rowOrderPreserved;
    int rowCount;
    int orientation;
    int layout_rowSpan;
    int layout_row;
    int layout_gravity;
    int layout_columnSpan;
    int layout_column;
    int columnOrderPreserved;
    int columnCount;
    int alignmentMode;
  }
}
class BuildConfig {
  int DEBUG;
}
