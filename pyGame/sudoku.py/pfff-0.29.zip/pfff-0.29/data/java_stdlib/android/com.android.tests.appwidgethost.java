package com.android.tests.appwidgethost;
class TestAppWidgetProvider {
  int PREF_PREFIX_KEY;
  int PREFS_NAME;
  int TAG;
}
class TestAppWidgetConfigure {
  int mOnClickListener;
  int TAG;
}
class AppWidgetHostActivity {
  int mHost;
  class MyAppWidgetView {
    int appWidgetId;
  }
  int mOnClickListener;
  int mAppWidgetContainer;
  int mAppWidgetManager;
  int PENDING_APPWIDGET_ID;
  int HOST_ID;
  int CONFIGURE_APPWIDGET_REQUEST;
  int DISCOVER_APPWIDGET_REQUEST;
  int TAG;
}
class AppWidgetContainerView {
}
