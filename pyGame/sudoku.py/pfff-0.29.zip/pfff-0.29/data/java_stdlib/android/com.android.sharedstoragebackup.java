package com.android.sharedstoragebackup;
class SharedStorageAgent {
  int mVolumes;
  int DEBUG;
  int TAG;
}
