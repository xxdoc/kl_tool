package com.android.framework.nolocversionedtestapp;
class NoLocVersionedTestAppActivity {
}
