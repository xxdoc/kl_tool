package com.android.internal.telephony.mockril;
class MockRilTest {
  int mRunner;
  int mMockRilChannel;
  int TAG;
}
class MockRilController {
  int mMessage;
  int mRilChannel;
  int TAG;
}
