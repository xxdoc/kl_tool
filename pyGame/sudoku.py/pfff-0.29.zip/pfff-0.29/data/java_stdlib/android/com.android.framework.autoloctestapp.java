package com.android.framework.autoloctestapp;
class AutoLocTestAppActivity {
}
