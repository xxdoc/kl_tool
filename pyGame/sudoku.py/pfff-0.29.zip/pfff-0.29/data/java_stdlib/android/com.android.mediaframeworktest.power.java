package com.android.mediaframeworktest.power;
class MediaPlayerPowerTest {
  int AAC_STREAM;
  int OGG_STREAM;
  int MP3_STREAM;
  int MP3_POWERTEST;
  int TAG;
}
