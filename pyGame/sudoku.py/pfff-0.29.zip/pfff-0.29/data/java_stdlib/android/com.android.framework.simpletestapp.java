package com.android.framework.simpletestapp;
class SimpleAppActivity {
}
