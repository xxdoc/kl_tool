package com.android.nfc_extras.tests;
class BasicNfcEeTest {
  int SELECT_CARD_MANAGER_RESPONSE;
  int SELECT_CARD_MANAGER_COMMAND;
  int mEe;
  int mAdapterExtras;
  int mContext;
}
