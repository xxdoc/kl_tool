package com.example.android.rs.computeperf;
class Mandelbrot {
  int mScript;
  int mAllocationXY;
  int mRS;
}
class LaunchTest {
  int mScript_xyw;
  int mScript_xlw;
  int mAllocationXY;
  int mAllocationX;
  int mRS;
}
class ComputePerf {
  int mRS;
  int mMandel;
  int mLT;
}
