package android.test.suitebuilder.examples.constructor;
class PublicConstructorTest {
}
class ProtectedConstructorTest {
}
class NoPublicConstructorTest {
}
