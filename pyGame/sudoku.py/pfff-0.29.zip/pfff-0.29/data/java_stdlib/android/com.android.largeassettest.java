package com.android.largeassettest;
class LargeAssetTest {
  class Validator {
    int TAG;
  }
  int mClickListener;
  int mValidateThread;
  int mResultText;
  int mValidateButton;
}
