package android.widget.scroll;
class TallTextAboveButton {
}
class ShortButtons {
  int mButtonHeightFactor;
  int mNumButtons;
}
class ScrollViewButtonsAndLabelsTest {
  int mScreenTop;
  int mScreenBottom;
  int mLinearLayout;
  int mScrollView;
}
class ScrollViewButtonsAndLabels {
  int mNumGroups;
  int mLinearLayout;
  int mScrollView;
}
class RequestRectangleVisibleWithInternalScrollTest {
  int mScrollView;
  int mScrollToBlob;
  int mTextBlob;
}
class RequestRectangleVisibleWithInternalScroll {
  int mScrollToBlob;
  int mTextBlob;
  int scrollYofBlob;
}
class RequestRectangleVisibleTest {
  int mClickToScrollFromBelow;
  int mClickToScrollToBlobLowerBlob;
  int mBottomBlob;
  int mChildToScrollTo;
  int mTopBlob;
  int mClickToScrollToUpperBlob;
  int mClickToScrollFromAbove;
  int mScrollView;
}
class RequestRectangleVisible {
}
class ButtonsWithTallTextViewInBetween {
}
class ButtonAboveTallInternalSelectionViewTest {
}
class ButtonAboveTallInternalSelectionView {
  int mNumRowsInIsv;
}
