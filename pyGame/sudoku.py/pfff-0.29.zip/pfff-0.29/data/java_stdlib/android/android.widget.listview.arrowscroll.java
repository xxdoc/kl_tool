package android.widget.listview.arrowscroll;
class ListWithSeparatorsTest {
  int mListView;
  int mActivity;
}
class ListWithScreenOfNoSelectablesTest {
  int mListView;
}
class ListWithOnItemSelectedActionTest {
  int mListView;
}
class ListWithOffScreenNextSelectableTest {
  int mListView;
}
class ListWithNoFadingEdgeTest {
  int mListView;
}
class ListWithFirstScreenUnSelectableTest {
  int mListView;
}
class ListOfThinItemsTest {
  int mListView;
}
class ListOfShortTallShortTest {
  int mListView;
}
class ListOfShortShortTallShortShortTest {
  int mListUtil;
  int mListView;
}
class ListOfItemsTallerThanScreenTest {
  int mActivity;
  int mListView;
}
class ListOfItemsShorterThanScreenTest {
  int mActivity;
  int mListView;
}
class ListLastItemPartiallyVisibleTest {
  int mListBottom;
  int mListView;
}
class ListItemsExpandOnSelectionTest {
  int mNormalHeight;
  int mExpandedHeight;
  int mListBottom;
  int mListTop;
  int mListView;
}
class ListItemFocusablesFarApartTest {
  int mListBottom;
  int mListTop;
  int mListView;
}
class ListItemFocusablesCloseTest {
  int mListBottom;
  int mListTop;
  int mListView;
}
class ListItemFocusableAboveUnfocusableTest {
  int mListView;
}
class ListInterleaveFocusablesTest {
  int mListUtil;
  int mListView;
}
