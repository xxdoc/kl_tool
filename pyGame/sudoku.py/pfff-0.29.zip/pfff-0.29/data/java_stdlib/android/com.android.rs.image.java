package com.android.rs.image;
class ImageProcessingTestRunner {
}
class ImageProcessingTest {
  int mAct;
  int ITERATION;
  int RESULT_FILE;
  int TAG;
}
class ImageProcessingActivity {
  int gaussian;
  int MAX_RADIUS;
  int out;
  int interm;
  int in;
  class FilterCallback {
    int mAction;
  }
  int mIsProcessing;
  int mDisplayView;
  int mSurfaceView;
  int mScratchPixelsAllocation2;
  int mScratchPixelsAllocation1;
  int mOutPixelsAllocation;
  int mInPixelsAllocation;
  int mPixelType;
  int mRS;
  int mBenchmarkResult;
  int mSaturationSeekBar;
  int mSaturation;
  int mGammaSeekBar;
  int mGamma;
  int mOutWhiteSeekBar;
  int mOutWhite;
  int mInWhiteSeekBar;
  int mInWhite;
  int mOutBlackSeekBar;
  int mOutBlack;
  int mInBlackSeekBar;
  int mInBlack;
  int mRadiusSeekBar;
  int mRadius;
  int mScriptHBlur;
  int mScriptVBlur;
  int mScript;
  int mBitmapOut;
  int mBitmapIn;
  int TAG;
}
