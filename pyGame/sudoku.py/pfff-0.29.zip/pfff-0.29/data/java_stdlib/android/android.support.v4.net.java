package android.support.v4.net;
class TrafficStatsCompatIcs {
}
class TrafficStatsCompat {
  int IMPL;
  class IcsTrafficStatsCompatImpl {
  }
  class BaseTrafficStatsCompatImpl {
    int mThreadSocketTags;
    class SocketTags {
      int statsTag;
    }
  }
  class TrafficStatsCompatImpl {
  }
}
class ConnectivityManagerCompatJellyBean {
}
class ConnectivityManagerCompatHoneycombMR2 {
}
class ConnectivityManagerCompatGingerbread {
}
class ConnectivityManagerCompat {
  int IMPL;
  class JellyBeanConnectivityManagerCompatImpl {
  }
  class HoneycombMR2ConnectivityManagerCompatImpl {
  }
  class GingerbreadConnectivityManagerCompatImpl {
  }
  class BaseConnectivityManagerCompatImpl {
  }
  class ConnectivityManagerCompatImpl {
  }
}
