package com.android.commands.bu;
class Backup {
  int mBackupManager;
  int mNextArg;
  int mArgs;
  int TAG;
}
