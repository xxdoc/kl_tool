package com.android.commands.input;
class Input {
  int TAG;
}
