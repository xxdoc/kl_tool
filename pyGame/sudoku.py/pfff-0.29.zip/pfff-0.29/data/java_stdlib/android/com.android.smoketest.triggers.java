package com.android.smoketest.triggers;
class UnresponsiveApp {
}
class CrashyApp2 {
}
class CrashyApp {
}
