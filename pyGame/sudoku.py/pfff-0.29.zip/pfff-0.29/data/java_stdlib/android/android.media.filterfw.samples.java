package android.media.filterfw.samples;
class CameraEffectsRecordingSample {
  int mRunButtonClick;
  int mOutFileName;
  int mCameraId;
  int mRunner;
  int mCameraView;
  int mRunButton;
}
